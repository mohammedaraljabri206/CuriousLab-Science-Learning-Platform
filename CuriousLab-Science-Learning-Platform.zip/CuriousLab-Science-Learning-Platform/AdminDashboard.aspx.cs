using System;
using System.Configuration;
using System.Data.SqlClient;

public partial class AdminDashboard : AdminPageBase
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (IsPostBack) return;
        lblAdminName.Text = "Signed in as " + Server.HtmlEncode(Convert.ToString(Session["FullName"]));
        try
        {
            using (var c = new SqlConnection(ConfigurationManager.ConnectionStrings["CuriousLabConnection"].ConnectionString))
            using (var cmd = new SqlCommand(@"SELECT
                (SELECT COUNT(*) FROM dbo.Users),
                (SELECT COUNT(*) FROM dbo.Experiments),
                (SELECT COUNT(*) FROM dbo.TheoryTopics),
                (SELECT COUNT(*) FROM dbo.Feedback)", c))
            {
                c.Open();
                using (var r = cmd.ExecuteReader())
                    if (r.Read())
                    {
                        lblUsers.Text = r.GetInt32(0).ToString();
                        lblExperiments.Text = r.GetInt32(1).ToString();
                        lblTheory.Text = r.GetInt32(2).ToString();
                        lblFeedback.Text = r.GetInt32(3).ToString();
                    }
            }
        }
        catch (SqlException)
        {
            lblMessage.Text = "Dashboard totals are unavailable. Run CuriousLab_Final.sql and check Web.config.";
        }
    }
}
