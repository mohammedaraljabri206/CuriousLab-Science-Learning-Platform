﻿<%@ Page Title="Chemistry Theory"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="Theory.aspx.cs"
    Inherits="Theory" %>

<asp:Content
    ID="Content1"
    ContentPlaceHolderID="head"
    runat="server">
</asp:Content>

<asp:Content
    ID="Content2"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <section class="theoryPage">

        <div class="theoryHeader">

            <span class="theoryLabel">
                LEARN THE SCIENCE
            </span>

            <h1>Chemistry Theory</h1>

            <p>
                Explore important chemistry concepts before performing
                the experiments.
            </p>

        </div>

        <div class="theorySearchContainer">

            <input
                type="text"
                id="theorySearch"
                class="theorySearchBox"
                placeholder="Search theory topics..."
                onkeyup="filterTheoryTopics()" />

        </div>

        <asp:Label
            ID="lblTheoryMessage"
            runat="server"
            CssClass="theoryMessage">
        </asp:Label>

        <asp:Repeater
            ID="rptTheoryTopics"
            runat="server">

            <HeaderTemplate>
                <div
                    id="theoryGrid"
                    class="theoryGrid">
            </HeaderTemplate>

            <ItemTemplate>

                <article
                    class="theoryCard searchableTheory"
                    data-title="<%# Eval("Title").ToString().ToLower() %>">

                    <div class="theoryImageContainer">

                        <asp:Image
                            ID="imgTheory"
                            runat="server"
                            CssClass="theoryImage"
                            ImageUrl='<%# Eval("ImagePath") %>'
                            AlternateText='<%# Eval("Title") %>' />

                    </div>

                    <div class="theoryCardContent">

                        <span class="theoryCardNumber">
                            TOPIC <%# Container.ItemIndex + 1 %>
                        </span>

                        <h2>
                            <%# Eval("Title") %>
                        </h2>

                        <p>
                            <%# Eval("ShortDescription") %>
                        </p>

                        <asp:HyperLink
                            ID="lnkReadTheory"
                            runat="server"
                            CssClass="theoryReadButton"
                            NavigateUrl='<%#
                                "~/TheoryDetails.aspx?id=" +
                                Eval("TheoryID")
                            %>'>

                            Read Theory →

                        </asp:HyperLink>

                    </div>

                </article>

            </ItemTemplate>

            <FooterTemplate>
                </div>
            </FooterTemplate>

        </asp:Repeater>

        <p
            id="noTheoryResults"
            class="noTheoryResults"
            style="display:none;">

            No theory topics match your search.

        </p>

    </section>

    <script type="text/javascript">

        function filterTheoryTopics() {

            var searchInput =
                document.getElementById("theorySearch");

            var searchValue =
                searchInput.value.toLowerCase().trim();

            var cards =
                document.getElementsByClassName(
                    "searchableTheory");

            var visibleCount = 0;

            for (var i = 0; i < cards.length; i++) {

                var title =
                    cards[i].getAttribute("data-title");

                if (title.indexOf(searchValue) !== -1) {

                    cards[i].style.display = "";
                    visibleCount++;

                } else {

                    cards[i].style.display = "none";

                }
            }

            document.getElementById(
                "noTheoryResults"
            ).style.display =
                visibleCount === 0
                    ? "block"
                    : "none";
        }

    </script>

</asp:Content>