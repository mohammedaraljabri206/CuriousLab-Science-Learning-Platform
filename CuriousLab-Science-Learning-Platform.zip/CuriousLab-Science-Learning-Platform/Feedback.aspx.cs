using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class Feedback : Member3PageBase
{
    private string ConnectionString
    {
        get { return ConfigurationManager.ConnectionStrings["CuriousLabConnection"].ConnectionString; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) LoadHistory();
    }

    protected void cvFeedback_ServerValidate(object source, ServerValidateEventArgs args)
    {
        args.IsValid = !string.IsNullOrWhiteSpace(args.Value) && args.Value.Trim().Length >= 10;
    }

    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        Page.Validate("FeedbackGroup");
        if (!Page.IsValid) return;
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = new SqlCommand(@"INSERT dbo.Feedback
            (UserID,Category,Subject,Message,Rating,Status,CreatedDate)
            VALUES(@UserID,@Category,@Subject,@Message,@Rating,N'New',GETDATE())", connection))
        {
            command.Parameters.Add("@UserID", SqlDbType.Int).Value = Session["UserID"];
            command.Parameters.Add("@Category", SqlDbType.NVarChar, 30).Value = ddlCategory.SelectedValue;
            command.Parameters.Add("@Subject", SqlDbType.NVarChar, 150).Value = txtSubject.Text.Trim();
            command.Parameters.Add("@Message", SqlDbType.NVarChar, 2000).Value = txtFeedback.Text.Trim();
            command.Parameters.Add("@Rating", SqlDbType.Int).Value = int.Parse(txtRating.Text);
            connection.Open();
            command.ExecuteNonQuery();
        }
        ddlCategory.SelectedIndex = 0; txtSubject.Text = ""; txtFeedback.Text = ""; txtRating.Text = "";
        lblMessage.Text = "Thank you. Your feedback was submitted successfully.";
        LoadHistory();
    }

    private void LoadHistory()
    {
        using (var connection = new SqlConnection(ConnectionString))
        using (var command = new SqlCommand(@"SELECT CreatedDate,Category,Subject,Rating,Status,
            COALESCE(AdminResponse,N'Not reviewed yet') AS AdminResponse
            FROM dbo.Feedback WHERE UserID=@UserID ORDER BY CreatedDate DESC", connection))
        using (var adapter = new SqlDataAdapter(command))
        {
            command.Parameters.Add("@UserID", SqlDbType.Int).Value = Session["UserID"];
            var table = new DataTable(); adapter.Fill(table);
            gridHistory.DataSource = table; gridHistory.DataBind();
        }
    }
}
