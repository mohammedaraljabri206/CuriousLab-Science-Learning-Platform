﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class Theory : System.Web.UI.Page
{
    private readonly string connectionString =
        ConfigurationManager
            .ConnectionStrings["CuriousLabConnection"]
            .ConnectionString;

    protected void Page_Load(
        object sender,
        EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadTheoryTopics();
        }
    }

    private void LoadTheoryTopics()
    {
        const string query =
            @"SELECT
                  TheoryID,
                  Title,
                  ShortDescription,
                  ImagePath
              FROM dbo.TheoryTopics
              WHERE IsActive = 1
              ORDER BY TheoryID";

        try
        {
            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            using (SqlCommand command =
                   new SqlCommand(query, connection))
            using (SqlDataAdapter adapter =
                   new SqlDataAdapter(command))
            {
                DataTable theoryTable =
                    new DataTable();

                adapter.Fill(theoryTable);

                rptTheoryTopics.DataSource =
                    theoryTable;

                rptTheoryTopics.DataBind();

                if (theoryTable.Rows.Count == 0)
                {
                    lblTheoryMessage.Text =
                        "No theory topics are currently available.";

                    lblTheoryMessage.CssClass =
                        "theoryMessage theoryError";
                }
            }
        }
        catch (SqlException)
        {
            lblTheoryMessage.Text =
                "Theory topics could not be loaded. Please try again.";

            lblTheoryMessage.CssClass =
                "theoryMessage theoryError";
        }
    }
}