﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;
public partial class UserProfile : System.Web.UI.Page
{
    private readonly string connectionString =
        ConfigurationManager
            .ConnectionStrings["CuriousLabConnection"]
            .ConnectionString;

    protected void Page_Load(
        object sender,
        EventArgs e)
    {
        // Prevent guests from directly opening Profile.aspx.
        if (Session["UserID"] == null)
        {
            Response.Redirect(
                "~/Login.aspx",
                false);

            Context.ApplicationInstance
                .CompleteRequest();

            return;
        }

        if (!IsPostBack)
        {
            LoadProfile();
        }
    }

    private void LoadProfile()
    {
        int userID;

        if (!int.TryParse(
            Session["UserID"].ToString(),
            out userID))
        {
            LogoutInvalidSession();
            return;
        }

        const string query =
            @"SELECT
                  FullName,
                  Email,
                  DateOfBirth,
                  MobileNumber,
                  Gender,
                  Role,
                  CreatedDate
              FROM dbo.Users
              WHERE UserID = @UserID
                AND IsActive = 1";

        try
        {
            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            using (SqlCommand command =
                   new SqlCommand(query, connection))
            {
                command.Parameters.Add(
                    "@UserID",
                    SqlDbType.Int).Value = userID;

                connection.Open();

                using (SqlDataReader reader =
                       command.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        LogoutInvalidSession();
                        return;
                    }

                    string fullName =
                        reader["FullName"].ToString();

                    txtFullName.Text = fullName;

                    txtEmail.Text =
                        reader["Email"].ToString();

                    txtDateOfBirth.Text =
                        reader["DateOfBirth"] == DBNull.Value
                            ? string.Empty
                            : Convert.ToDateTime(
                                reader["DateOfBirth"])
                              .ToString("yyyy-MM-dd");

                    txtMobileNumber.Text =
                        reader["MobileNumber"] == DBNull.Value
                            ? string.Empty
                            : reader["MobileNumber"].ToString();

                    string gender =
                        reader["Gender"] == DBNull.Value
                            ? string.Empty
                            : reader["Gender"].ToString();

                    if (ddlGender.Items
                        .FindByValue(gender) != null)
                    {
                        ddlGender.SelectedValue = gender;
                    }
                    else
                    {
                        ddlGender.SelectedIndex = 0;
                    }

                    txtRole.Text =
                        reader["Role"].ToString();

                    txtCreatedDate.Text =
                        reader["CreatedDate"] == DBNull.Value
                            ? string.Empty
                            : Convert.ToDateTime(
                                reader["CreatedDate"])
                              .ToString("dd MMMM yyyy");

                    lblInitials.Text =
                        GetInitials(fullName);
                }
            }
        }
        catch (SqlException)
        {
            ShowError(
                "Your profile could not be loaded. Please try again.");
        }
    }

    protected void btnEdit_Click(
        object sender,
        EventArgs e)
    {
        SetEditMode(true);
        ClearMessage();
    }

    protected void btnCancel_Click(
        object sender,
        EventArgs e)
    {
        SetEditMode(false);
        ClearMessage();
        LoadProfile();
    }

    protected void btnSave_Click(
        object sender,
        EventArgs e)
    {
        Page.Validate("ProfileGroup");

        if (!Page.IsValid)
        {
            return;
        }

        DateTime dateOfBirth;

        if (!DateTime.TryParse(
            txtDateOfBirth.Text,
            out dateOfBirth))
        {
            ShowError(
                "Please enter a valid date of birth.");

            return;
        }

        if (dateOfBirth.Date > DateTime.Today)
        {
            ShowError(
                "Date of birth cannot be in the future.");

            return;
        }

        int userID;

        if (!int.TryParse(
            Session["UserID"].ToString(),
            out userID))
        {
            LogoutInvalidSession();
            return;
        }

        const string updateQuery =
            @"UPDATE dbo.Users
              SET
                  FullName = @FullName,
                  DateOfBirth = @DateOfBirth,
                  MobileNumber = @MobileNumber,
                  Gender = @Gender
              WHERE UserID = @UserID
                AND IsActive = 1";

        try
        {
            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            using (SqlCommand command =
                   new SqlCommand(updateQuery, connection))
            {
                command.Parameters.Add(
                    "@FullName",
                    SqlDbType.NVarChar,
                    100).Value =
                    txtFullName.Text.Trim();

                command.Parameters.Add(
                    "@DateOfBirth",
                    SqlDbType.Date).Value =
                    dateOfBirth.Date;

                command.Parameters.Add(
                    "@MobileNumber",
                    SqlDbType.NVarChar,
                    20).Value =
                    txtMobileNumber.Text.Trim();

                command.Parameters.Add(
                    "@Gender",
                    SqlDbType.NVarChar,
                    20).Value =
                    ddlGender.SelectedValue;

                command.Parameters.Add(
                    "@UserID",
                    SqlDbType.Int).Value =
                    userID;

                connection.Open();

                int rowsAffected =
                    command.ExecuteNonQuery();

                if (rowsAffected == 0)
                {
                    ShowError(
                        "Your profile could not be updated.");

                    return;
                }
            }

            string updatedFullName =
                txtFullName.Text.Trim();

            Session["FullName"] =
                updatedFullName;

            lblInitials.Text =
                GetInitials(updatedFullName);

            SetEditMode(false);

            ShowSuccess(
                "Your profile was updated successfully.");
        }
        catch (SqlException)
        {
            ShowError(
                "Your changes could not be saved. Please try again.");
        }
    }

    protected void cvDateOfBirth_ServerValidate(
        object source,
        ServerValidateEventArgs args)
    {
        DateTime dateOfBirth;

        args.IsValid =
            DateTime.TryParse(
                args.Value,
                out dateOfBirth)
            &&
            dateOfBirth.Date <= DateTime.Today;
    }

    private void SetEditMode(bool editing)
    {
        txtFullName.Enabled = editing;
        txtDateOfBirth.Enabled = editing;
        txtMobileNumber.Enabled = editing;
        ddlGender.Enabled = editing;

        btnEdit.Visible = !editing;
        pnlProfileActions.Visible = editing;
    }

    private static string GetInitials(
        string fullName)
    {
        if (string.IsNullOrWhiteSpace(fullName))
        {
            return "CL";
        }

        string[] nameParts =
            fullName.Split(
                new[] { ' ' },
                StringSplitOptions.RemoveEmptyEntries);

        if (nameParts.Length == 1)
        {
            return nameParts[0]
                .Substring(0, 1)
                .ToUpperInvariant();
        }

        return (
            nameParts[0].Substring(0, 1)
            +
            nameParts[nameParts.Length - 1]
                .Substring(0, 1))
            .ToUpperInvariant();
    }

    private void ShowSuccess(string message)
    {
        lblProfileMessage.CssClass =
            "profileMessage profileSuccess";

        lblProfileMessage.Text =
            Server.HtmlEncode(message);
    }

    private void ShowError(string message)
    {
        lblProfileMessage.CssClass =
            "profileMessage profileError";

        lblProfileMessage.Text =
            Server.HtmlEncode(message);
    }

    private void ClearMessage()
    {
        lblProfileMessage.Text =
            string.Empty;

        lblProfileMessage.CssClass =
            string.Empty;
    }

    private void LogoutInvalidSession()
    {
        Session.Clear();
        Session.Abandon();

        Response.Redirect(
            "~/Login.aspx",
            false);

        Context.ApplicationInstance
            .CompleteRequest();
    }
}