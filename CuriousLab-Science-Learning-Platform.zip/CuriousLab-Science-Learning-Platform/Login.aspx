﻿<%@ Page Title="Login" Language="C#" MasterPageFile="~/Master.master"
    AutoEventWireup="true" CodeFile="Login.aspx.cs" Inherits="Login" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="head"
    runat="server">
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="login-container">

        <div class="login-card">

            <h1>Welcome Back!</h1>

            <p class="login-subtitle">
                Login to continue your chemistry learning journey.
            </p>

            <asp:Label
                ID="lblLoginMessage"
                runat="server"
                CssClass="loginMessage"
                EnableViewState="false">
            </asp:Label>

            <div class="form-group">

                <label>Email Address</label>

                <asp:TextBox
                    ID="txtEmail"
                    runat="server"
                    CssClass="textbox"
                    TextMode="Email"
                    MaxLength="100"
                    placeholder="Enter your email">
                </asp:TextBox>

                <asp:RequiredFieldValidator
                    ID="rfvLoginEmail"
                    runat="server"
                    ControlToValidate="txtEmail"
                    ErrorMessage="Email Address is required."
                    CssClass="fieldError"
                    Display="Dynamic"
                    ValidationGroup="LoginGroup">
                </asp:RequiredFieldValidator>

                <asp:RegularExpressionValidator
                    ID="revLoginEmail"
                    runat="server"
                    ControlToValidate="txtEmail"
                    ErrorMessage="Please enter a valid email address."
                    ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]+$"
                    CssClass="fieldError"
                    Display="Dynamic"
                    ValidationGroup="LoginGroup">
                </asp:RegularExpressionValidator>

            </div>

            <div class="form-group">

                <label>Password</label>

                <asp:TextBox
                    ID="txtPassword"
                    runat="server"
                    CssClass="textbox"
                    TextMode="Password"
                    MaxLength="100"
                    placeholder="Enter your password">
                </asp:TextBox>

                <asp:RequiredFieldValidator
                    ID="rfvLoginPassword"
                    runat="server"
                    ControlToValidate="txtPassword"
                    ErrorMessage="Password is required."
                    CssClass="fieldError"
                    Display="Dynamic"
                    ValidationGroup="LoginGroup">
                </asp:RequiredFieldValidator>

            </div>

            <div class="remember-row">

                <asp:CheckBox
                    ID="chkRemember"
                    runat="server"
                    Text=" Remember Me" />

            </div>

            <asp:Button
                ID="btnLogin"
                runat="server"
                Text="LOGIN"
                CssClass="login-btn"
                ValidationGroup="LoginGroup"
                OnClick="btnLogin_Click" />

            <p class="register-link">
                Don't have an account?
                <a href="Register.aspx">Create Account</a>
            </p>

        </div>

    </div>

</asp:Content>