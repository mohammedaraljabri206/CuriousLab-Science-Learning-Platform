﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Web.UI;

public partial class Register : Page
{
    private readonly string connectionString =
        ConfigurationManager.ConnectionStrings[
            "CuriousLabConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
    }

    protected void cvDateOfBirth_ServerValidate(
        object source,
        System.Web.UI.WebControls.ServerValidateEventArgs args)
    {
        DateTime dateOfBirth;

        args.IsValid =
            DateTime.TryParse(args.Value, out dateOfBirth) &&
            dateOfBirth.Date <= DateTime.Today;
    }

    protected void btnRegister_Click(object sender, EventArgs e)
    {
        Page.Validate("RegisterGroup");

        if (!Page.IsValid)
        {
            lblRegisterMessage.Text = string.Empty;
            return;
        }

        DateTime dateOfBirth;

        if (!DateTime.TryParse(txtDateOfBirth.Text, out dateOfBirth))
        {
            ShowError("Please enter a valid date of birth.");
            return;
        }

        string fullName = txtFullName.Text.Trim();
        string email = txtEmail.Text.Trim().ToLowerInvariant();
        string mobileNumber = txtMobileNumber.Text.Trim();
        string gender = rblGender.SelectedValue;
        string passwordHash = HashPassword(txtPassword.Text);

        try
        {
            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            {
                connection.Open();

                string checkEmailQuery =
                    @"SELECT COUNT(*)
                      FROM Users
                      WHERE Email = @Email";

                using (SqlCommand checkCommand =
                       new SqlCommand(checkEmailQuery, connection))
                {
                    checkCommand.Parameters.Add(
                        "@Email",
                        SqlDbType.NVarChar,
                        100).Value = email;

                    int existingUserCount =
                        Convert.ToInt32(checkCommand.ExecuteScalar());

                    if (existingUserCount > 0)
                    {
                        ShowError(
                            "An account with this email address already exists.");
                        return;
                    }
                }

                string insertQuery =
                    @"INSERT INTO Users
                      (
                          FullName,
                          Email,
                          DateOfBirth,
                          MobileNumber,
                          Gender,
                          PasswordHash,
                          Role,
                          IsActive
                      )
                      VALUES
                      (
                          @FullName,
                          @Email,
                          @DateOfBirth,
                          @MobileNumber,
                          @Gender,
                          @PasswordHash,
                          @Role,
                          @IsActive
                      )";

                using (SqlCommand insertCommand =
                       new SqlCommand(insertQuery, connection))
                {
                    insertCommand.Parameters.Add(
                        "@FullName",
                        SqlDbType.NVarChar,
                        100).Value = fullName;

                    insertCommand.Parameters.Add(
                        "@Email",
                        SqlDbType.NVarChar,
                        100).Value = email;

                    insertCommand.Parameters.Add(
                        "@DateOfBirth",
                        SqlDbType.Date).Value = dateOfBirth.Date;

                    insertCommand.Parameters.Add(
                        "@MobileNumber",
                        SqlDbType.NVarChar,
                        20).Value = mobileNumber;

                    insertCommand.Parameters.Add(
                        "@Gender",
                        SqlDbType.NVarChar,
                        20).Value = gender;

                    insertCommand.Parameters.Add(
                        "@PasswordHash",
                        SqlDbType.NVarChar,
                        255).Value = passwordHash;

                    insertCommand.Parameters.Add(
                        "@Role",
                        SqlDbType.NVarChar,
                        20).Value = "Student";

                    insertCommand.Parameters.Add(
                        "@IsActive",
                        SqlDbType.Bit).Value = true;

                    insertCommand.ExecuteNonQuery();
                }
            }

            Response.Redirect(
                "Login.aspx?registered=1",
                false);

            Context.ApplicationInstance.CompleteRequest();
        }
        catch (SqlException)
        {
            ShowError(
                "Registration could not be completed. Please try again.");
        }
    }

    private void ShowError(string message)
    {
        lblRegisterMessage.CssClass =
            "registerMessage registerError";

        lblRegisterMessage.Text =
            Server.HtmlEncode(message);
    }

    private static string HashPassword(string password)
    {
        const int saltSize = 16;
        const int hashSize = 32;
        const int iterations = 100000;

        byte[] salt = new byte[saltSize];

        using (RandomNumberGenerator random =
               RandomNumberGenerator.Create())
        {
            random.GetBytes(salt);
        }

        byte[] hash;

        using (Rfc2898DeriveBytes pbkdf2 =
               new Rfc2898DeriveBytes(
                   password,
                   salt,
                   iterations,
                   HashAlgorithmName.SHA256))
        {
            hash = pbkdf2.GetBytes(hashSize);
        }

        return iterations + "." +
               Convert.ToBase64String(salt) + "." +
               Convert.ToBase64String(hash);
    }
}