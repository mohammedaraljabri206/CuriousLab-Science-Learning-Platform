using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class AdminManage : AdminPageBase
{
    private sealed class FieldDef
    {
        public string Name, Label; public int Size; public bool Required, Multiline;
        public FieldDef(string n, string l, int s, bool r, bool m = false)
        { Name = n; Label = l; Size = s; Required = r; Multiline = m; }
    }

    private string Section { get { return (Request.QueryString["section"] ?? "users").ToLowerInvariant(); } }
    private string Cs { get { return ConfigurationManager.ConnectionStrings["CuriousLabConnection"].ConnectionString; } }

    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        BuildEditor();
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) BindGrid();
    }

    private FieldDef[] Fields()
    {
        switch (Section)
        {
            case "experiments": return new[] {
                new FieldDef("ExperimentName","Name",150,true), new FieldDef("Difficulty","Difficulty (Easy/Intermediate/Advanced)",20,true),
                new FieldDef("TimeRequired","Time required",50,true), new FieldDef("Materials","Materials",1000,true,true),
                new FieldDef("ProcedureSteps","Procedure",4000,true,true), new FieldDef("Safety","Safety",1000,true,true),
                new FieldDef("Explanation","Explanation",4000,true,true), new FieldDef("ExpectedResult","Expected result",1000,true,true),
                new FieldDef("Image","Image filename",255,false) };
            case "theory": return new[] {
                new FieldDef("Title","Title",100,true), new FieldDef("ShortDescription","Short description",300,true,true),
                new FieldDef("Introduction","Introduction",4000,true,true), new FieldDef("KeyConcepts","Key concepts (separate with |)",4000,true,true),
                new FieldDef("RealLifeExamples","Examples (separate with |)",4000,true,true), new FieldDef("ImagePath","Image path",255,true) };
            case "quiz": return new[] {
                new FieldDef("QuestionText","Question",1000,true,true), new FieldDef("OptionA","Option A",300,true),
                new FieldDef("OptionB","Option B",300,true), new FieldDef("OptionC","Option C",300,true),
                new FieldDef("OptionD","Option D",300,true), new FieldDef("CorrectOption","Correct option (A/B/C/D)",1,true),
                new FieldDef("Explanation","Explanation",1000,false,true) };
            case "feedback": return new[] { new FieldDef("AdminResponse","Admin response",1000,false,true) };
            default: return new[] {
                new FieldDef("FullName","Full name",100,true), new FieldDef("Email","Email",100,true),
                new FieldDef("Role","Role (Student/Admin)",20,true), new FieldDef("IsActive","Active (true/false)",5,true) };
        }
    }

    private void BuildEditor()
    {
        foreach (FieldDef f in Fields())
        {
            var wrap = new Panel { CssClass = "admin-field" };
            wrap.Controls.Add(new Label { Text = Server.HtmlEncode(f.Label), AssociatedControlID = "txt_" + f.Name });
            var box = new TextBox { ID = "txt_" + f.Name, CssClass = "admin-input", MaxLength = f.Size };
            if (f.Multiline) { box.TextMode = TextBoxMode.MultiLine; box.Rows = 3; }
            wrap.Controls.Add(box);
            if (f.Required)
                wrap.Controls.Add(new RequiredFieldValidator { ControlToValidate = box.ID, ErrorMessage = f.Label + " is required.", Text = " *", ValidationGroup = "AdminForm", CssClass = "admin-error" });
            pnlEditor.Controls.Add(wrap);
        }
        if (Section == "feedback") btnAdd.Visible = false;
    }

    private string TableName()
    {
        switch (Section) { case "experiments": return "Experiments"; case "theory": return "TheoryTopics"; case "quiz": return "QuizQuestions"; case "feedback": return "Feedback"; default: return "Users"; }
    }
    private string KeyName()
    {
        switch (Section) { case "experiments": return "ExperimentID"; case "theory": return "TheoryID"; case "quiz": return "QuestionID"; case "feedback": return "FeedbackID"; default: return "UserID"; }
    }

    private void BindGrid()
    {
        lblTitle.Text = "Manage " + (Section == "theory" ? "Theory" : char.ToUpper(Section[0]) + Section.Substring(1));
        string cols;
        switch (Section)
        {
            case "experiments": cols = "ExperimentID AS ID, ExperimentName, Difficulty, TimeRequired, IsActive"; break;
            case "theory": cols = "TheoryID AS ID, Title, ShortDescription, IsActive"; break;
            case "quiz": cols = "QuestionID AS ID, QuestionText, CorrectOption, IsActive"; break;
            case "feedback": cols = "FeedbackID AS ID, UserID, Subject, Message, Rating, Status, AdminResponse, CreatedDate"; break;
            default: cols = "UserID AS ID, FullName, Email, Role, IsActive, CreatedDate"; break;
        }
        using (var a = new SqlDataAdapter("SELECT " + cols + " FROM dbo." + TableName() + " ORDER BY " + KeyName() + " DESC", Cs))
        {
            var dt = new DataTable(); a.Fill(dt); grid.DataSource = dt; grid.DataBind();
        }
    }

    protected void btnAdd_Click(object sender, EventArgs e)
    {
        Page.Validate("AdminForm"); if (!Page.IsValid) return;
        var fs = Fields(); var names = new List<string>(); var pars = new List<string>();
        foreach (var f in fs) { names.Add(f.Name); pars.Add("@" + f.Name); }
        string extraNames = "", extraValues = "";
        if (Section == "users") { extraNames = ", DateOfBirth, MobileNumber, Gender, PasswordHash, CreatedDate"; extraValues = ", '2000-01-01', 'Not supplied', 'Not supplied', @PasswordHash, GETDATE()"; }
        if (Section == "experiments" || Section == "theory" || Section == "quiz") { extraNames += ", IsActive"; extraValues += ", 1"; }
        using (var c = new SqlConnection(Cs))
        using (var cmd = new SqlCommand("INSERT INTO dbo." + TableName() + " (" + string.Join(",", names) + extraNames + ") VALUES (" + string.Join(",", pars) + extraValues + ")", c))
        {
            AddParameters(cmd, fs, false);
            if (Section == "users") cmd.Parameters.Add("@PasswordHash", SqlDbType.NVarChar, 255).Value = PasswordUtility.Hash("ChangeMe123!");
            c.Open(); cmd.ExecuteNonQuery();
        }
        ClearEditor(); lblMessage.Text = Section == "users" ? "User added with temporary password ChangeMe123!." : "Record added successfully."; BindGrid();
    }

    private void AddParameters(SqlCommand cmd, FieldDef[] fs, bool fromGrid)
    {
        foreach (var f in fs)
        {
            string value = fromGrid ? "" : FindTextBox(pnlEditor, "txt_" + f.Name).Text.Trim();
            object final = value;
            if (f.Name == "IsActive") { bool b; if (!bool.TryParse(value, out b)) throw new InvalidOperationException("Active must be true or false."); final = b; }
            cmd.Parameters.Add("@" + f.Name, f.Name == "IsActive" ? SqlDbType.Bit : SqlDbType.NVarChar, f.Size).Value = final;
        }
    }

    protected void grid_RowEditing(object sender, GridViewEditEventArgs e) { grid.EditIndex = e.NewEditIndex; BindGrid(); }
    protected void grid_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e) { grid.EditIndex = -1; BindGrid(); }
    protected void grid_RowUpdating(object sender, GridViewUpdateEventArgs e)
    {
        int id = Convert.ToInt32(grid.DataKeys[e.RowIndex].Value);
        var row = grid.Rows[e.RowIndex]; var updates = new List<string>(); var cmd = new SqlCommand();
        for (int i = 2; i < row.Cells.Count; i++)
        {
            if (!(row.Cells[i].Controls.Count > 0 && row.Cells[i].Controls[0] is TextBox)) continue;
            string col = grid.HeaderRow.Cells[i].Text; if (col == "ID" || col == "CreatedDate" || col == "UserID") continue;
            string val = ((TextBox)row.Cells[i].Controls[0]).Text.Trim();
            updates.Add("[" + col + "]=@" + col); cmd.Parameters.AddWithValue("@" + col, val);
        }
        cmd.CommandText = "UPDATE dbo." + TableName() + " SET " + string.Join(",", updates) + " WHERE " + KeyName() + "=@ID";
        cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id; cmd.Connection = new SqlConnection(Cs);
        try { cmd.Connection.Open(); cmd.ExecuteNonQuery(); lblMessage.Text = "Record updated successfully."; }
        finally { cmd.Connection.Dispose(); }
        grid.EditIndex = -1; BindGrid();
    }
    protected void grid_RowDeleting(object sender, GridViewDeleteEventArgs e)
    {
        int id = Convert.ToInt32(grid.DataKeys[e.RowIndex].Value);
        if (Section == "users" && Session["UserID"] != null && id == Convert.ToInt32(Session["UserID"])) { lblMessage.Text = "You cannot delete your own signed-in account."; return; }
        using (var c = new SqlConnection(Cs))
        using (var cmd = new SqlCommand("DELETE FROM dbo." + TableName() + " WHERE " + KeyName() + "=@ID", c))
        { cmd.Parameters.Add("@ID", SqlDbType.Int).Value = id; c.Open(); cmd.ExecuteNonQuery(); }
        lblMessage.Text = "Record deleted successfully."; BindGrid();
    }
    private static TextBox FindTextBox(Control parent, string id)
    {
        foreach (Control child in parent.Controls)
        {
            if (child.ID == id && child is TextBox) return (TextBox)child;
            TextBox found = FindTextBox(child, id);
            if (found != null) return found;
        }
        return null;
    }
    private void ClearEditor() { foreach (var f in Fields()) FindTextBox(pnlEditor, "txt_" + f.Name).Text = ""; }
}

public static class PasswordUtility
{
    public static string Hash(string password)
    {
        const int iterations = 100000; byte[] salt = new byte[16];
        using (var rng = System.Security.Cryptography.RandomNumberGenerator.Create()) rng.GetBytes(salt);
        byte[] hash;
        using (var p = new System.Security.Cryptography.Rfc2898DeriveBytes(password, salt, iterations, System.Security.Cryptography.HashAlgorithmName.SHA256)) hash = p.GetBytes(32);
        return iterations + "." + Convert.ToBase64String(salt) + "." + Convert.ToBase64String(hash);
    }
}
