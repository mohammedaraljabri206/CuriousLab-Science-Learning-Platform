<%@ Page Title="Admin Dashboard" Language="C#" MasterPageFile="~/Master.master"
    AutoEventWireup="true" CodeFile="AdminDashboard.aspx.cs" Inherits="AdminDashboard" %>
<asp:Content ID="AdminContent" ContentPlaceHolderID="MainContent" runat="server">
    <section class="admin-shell">
        <div class="admin-heading">
            <div><span class="eyebrow">ADMINISTRATION</span><h1>CuriousLab Control Centre</h1>
            <p>Manage learning content, assessments, users and feedback.</p></div>
            <asp:Label ID="lblAdminName" runat="server" CssClass="admin-welcome" />
        </div>
        <div class="admin-stats">
            <div><strong><asp:Label ID="lblUsers" runat="server" /></strong><span>Users</span></div>
            <div><strong><asp:Label ID="lblExperiments" runat="server" /></strong><span>Experiments</span></div>
            <div><strong><asp:Label ID="lblTheory" runat="server" /></strong><span>Theory topics</span></div>
            <div><strong><asp:Label ID="lblFeedback" runat="server" /></strong><span>Feedback items</span></div>
        </div>
        <div class="admin-cards">
            <a href="AdminManage.aspx?section=users"><b>Manage Users</b><span>Accounts, roles and status</span></a>
            <a href="AdminManage.aspx?section=experiments"><b>Manage Experiments</b><span>Instructions and safety content</span></a>
            <a href="AdminManage.aspx?section=theory"><b>Manage Theory</b><span>Learning topics and examples</span></a>
            <a href="AdminManage.aspx?section=quiz"><b>Manage Quiz</b><span>Questions, answers and explanations</span></a>
            <a href="AdminManage.aspx?section=feedback"><b>Manage Feedback</b><span>Review, resolve and remove submissions</span></a>
        </div>
        <asp:Label ID="lblMessage" runat="server" CssClass="admin-message" />
    </section>
</asp:Content>
