﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Security.Cryptography;

public partial class Login : System.Web.UI.Page
{
    private readonly string connectionString =
        ConfigurationManager.ConnectionStrings[
            "CuriousLabConnection"].ConnectionString;

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack &&
            Request.QueryString["registered"] == "1")
        {
            lblLoginMessage.CssClass =
                "loginMessage loginSuccess";

            lblLoginMessage.Text =
                "Your account was created successfully. You can now log in.";
        }
    }

    protected void btnLogin_Click(object sender, EventArgs e)
    {
        Page.Validate("LoginGroup");

        if (!Page.IsValid)
        {
            return;
        }

        string email =
            txtEmail.Text.Trim().ToLowerInvariant();

        string password =
            txtPassword.Text;

        try
        {
            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            {
                const string query =
                    @"SELECT
                          UserID,
                          FullName,
                          Email,
                          PasswordHash,
                          Role,
                          IsActive
                      FROM Users
                      WHERE Email = @Email";

                using (SqlCommand command =
                       new SqlCommand(query, connection))
                {
                    command.Parameters.Add(
                        "@Email",
                        SqlDbType.NVarChar,
                        100).Value = email;

                    connection.Open();

                    using (SqlDataReader reader =
                           command.ExecuteReader())
                    {
                        if (!reader.Read())
                        {
                            ShowLoginError(
                                "Invalid email address or password.");
                            return;
                        }

                        bool isActive =
                            Convert.ToBoolean(
                                reader["IsActive"]);

                        if (!isActive)
                        {
                            ShowLoginError(
                                "This account has been deactivated.");
                            return;
                        }

                        string storedPasswordHash =
                            reader["PasswordHash"].ToString();

                        bool passwordIsCorrect =
                            VerifyPassword(
                                password,
                                storedPasswordHash);

                        if (!passwordIsCorrect)
                        {
                            ShowLoginError(
                                "Invalid email address or password.");
                            return;
                        }

                        Session["UserID"] =
                            Convert.ToInt32(
                                reader["UserID"]);

                        Session["FullName"] =
                            reader["FullName"].ToString();

                        Session["Email"] =
                            reader["Email"].ToString();

                        Session["Role"] =
                            reader["Role"].ToString();
                    }
                }
            }

            string role =
                Convert.ToString(Session["Role"]);

            if (role.Equals(
                "Admin",
                StringComparison.OrdinalIgnoreCase))
            {
                Response.Redirect(
                    "AdminDashboard.aspx",
                    false);
            }
            else
            {
                Response.Redirect(
                    "Home.aspx",
                    false);
            }

            Context.ApplicationInstance.CompleteRequest();
        }
        catch (SqlException)
        {
            ShowLoginError(
                "Login could not be completed. Please try again.");
        }
    }

    private void ShowLoginError(string message)
    {
        lblLoginMessage.CssClass =
            "loginMessage loginError";

        lblLoginMessage.Text =
            Server.HtmlEncode(message);
    }

    private static bool VerifyPassword(
        string password,
        string storedPasswordHash)
    {
        if (string.IsNullOrWhiteSpace(storedPasswordHash))
        {
            return false;
        }

        string[] parts =
            storedPasswordHash.Split('.');

        if (parts.Length != 3)
        {
            return false;
        }

        int iterations;

        if (!int.TryParse(parts[0], out iterations))
        {
            return false;
        }

        byte[] salt;
        byte[] expectedHash;

        try
        {
            salt =
                Convert.FromBase64String(parts[1]);

            expectedHash =
                Convert.FromBase64String(parts[2]);
        }
        catch (FormatException)
        {
            return false;
        }

        byte[] actualHash;

        using (Rfc2898DeriveBytes pbkdf2 =
               new Rfc2898DeriveBytes(
                   password,
                   salt,
                   iterations,
                   HashAlgorithmName.SHA256))
        {
            actualHash =
                pbkdf2.GetBytes(expectedHash.Length);
        }

        return FixedTimeEquals(
            actualHash,
            expectedHash);
    }

    private static bool FixedTimeEquals(
        byte[] first,
        byte[] second)
    {
        if (first == null ||
            second == null ||
            first.Length != second.Length)
        {
            return false;
        }

        int difference = 0;

        for (int i = 0; i < first.Length; i++)
        {
            difference |= first[i] ^ second[i];
        }

        return difference == 0;
    }
}