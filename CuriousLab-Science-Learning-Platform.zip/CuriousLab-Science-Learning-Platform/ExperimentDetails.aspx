﻿<%@ Page Title="Experiment Details"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="ExperimentDetails.aspx.cs"
    Inherits="ExperimentDetails" %>
<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server"><div class="detailsContainer">

    <h1 class="detailsTitle">
        <asp:Label ID="lblTitle" runat="server"></asp:Label>
    </h1>

    <asp:Image
        ID="imgExperiment"
        runat="server"
        CssClass="detailsImage" />

    <div class="detailsCard">

        <h3>⏱ Time Required</h3>
        <asp:Label ID="lblTime" runat="server"></asp:Label>

        <hr />

        <h3>🧪 Materials</h3>
        <asp:Label ID="lblMaterials" runat="server"></asp:Label>


        <hr />

        <h3>📋 Procedure</h3>
        <asp:Label ID="lblProcedure" runat="server"></asp:Label>
        <br /><br />

<asp:Label
    ID="lblProcedureNote" 
    runat="server" 
    CssClass="procedureNote">

</asp:Label>
        <hr />

        <h3>⚠ Safety Precautions</h3>
        <asp:Label ID="lblSafety" runat="server"></asp:Label>

        <hr />

        <h3>🔬 Scientific Explanation</h3>
        <asp:Label ID="lblExplanation" runat="server"></asp:Label>

        <hr />

        <h3>✅ Expected Result</h3>
        <asp:Label ID="lblResult" runat="server"></asp:Label>

    </div>

</div>
</asp:Content>
