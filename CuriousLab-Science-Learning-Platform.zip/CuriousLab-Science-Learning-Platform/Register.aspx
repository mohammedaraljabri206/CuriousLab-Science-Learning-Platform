﻿<%@ Page Title="Create Account" Language="C#" MasterPageFile="~/Master.master"
    AutoEventWireup="true" CodeFile="Register.aspx.cs" Inherits="Register" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">

    <div class="registerPage">

        <div class="registerCard">

            <div class="registerHeader">
                <span class="registerLabel">JOIN CURIOUSLAB</span>

                <h1>Create Account</h1>

                <p>
                    Create your CuriousLab account and begin exploring chemistry
                    through experiments, theory materials, quizzes, and practical
                    learning activities.
                </p>
            </div>

            <!-- Validation summary -->
            <asp:ValidationSummary
                ID="vsRegister"
                runat="server"
                CssClass="validationSummary"
                HeaderText="Please resolve the following:"
                DisplayMode="BulletList"
                ValidationGroup="RegisterGroup" />

            <!-- General database message -->
            <asp:Label
                ID="lblRegisterMessage"
                runat="server"
                CssClass="registerMessage"
                EnableViewState="false">
            </asp:Label>

            <div class="registerGrid">

                <!-- Full Name -->
                <div class="registerField fullWidthField">
                    <asp:Label
                        ID="lblFullName"
                        runat="server"
                        AssociatedControlID="txtFullName"
                        Text="Full Name">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtFullName"
                        runat="server"
                        CssClass="registerTextbox"
                        MaxLength="100"
                        placeholder="e.g. Marie Curie">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvFullName"
                        runat="server"
                        ControlToValidate="txtFullName"
                        ErrorMessage="Full Name is required."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RequiredFieldValidator>
                </div>

                <!-- Email -->
                <div class="registerField">
                    <asp:Label
                        ID="lblEmail"
                        runat="server"
                        AssociatedControlID="txtEmail"
                        Text="Email Address">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtEmail"
                        runat="server"
                        CssClass="registerTextbox"
                        TextMode="Email"
                        MaxLength="120"
                        placeholder="name@example.com">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvEmail"
                        runat="server"
                        ControlToValidate="txtEmail"
                        ErrorMessage="Email Address is required."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RequiredFieldValidator>

                    <asp:RegularExpressionValidator
                        ID="revEmail"
                        runat="server"
                        ControlToValidate="txtEmail"
                        ErrorMessage="Please enter a valid email address."
                        ValidationExpression="^[^@\s]+@[^@\s]+\.[^@\s]+$"
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RegularExpressionValidator>
                </div>

                <!-- Date of Birth -->
                <div class="registerField">
                    <asp:Label
                        ID="lblDateOfBirth"
                        runat="server"
                        AssociatedControlID="txtDateOfBirth"
                        Text="Date of Birth">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtDateOfBirth"
                        runat="server"
                        CssClass="registerTextbox"
                        TextMode="Date">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvDateOfBirth"
                        runat="server"
                        ControlToValidate="txtDateOfBirth"
                        ErrorMessage="Date of Birth is required."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RequiredFieldValidator>

                    <asp:CustomValidator
                        ID="cvDateOfBirth"
                        runat="server"
                        ControlToValidate="txtDateOfBirth"
                        ErrorMessage="Please enter a valid date of birth that is not in the future."
                        CssClass="fieldError"
                        Display="Dynamic"
                        OnServerValidate="cvDateOfBirth_ServerValidate"
                        ValidationGroup="RegisterGroup">
                    </asp:CustomValidator>
                </div>

                <!-- Mobile Number -->
                <div class="registerField">
                    <asp:Label
                        ID="lblMobileNumber"
                        runat="server"
                        AssociatedControlID="txtMobileNumber"
                        Text="Mobile Number">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtMobileNumber"
                        runat="server"
                        CssClass="registerTextbox"
                        MaxLength="20"
                        placeholder="+60 12-345 6789">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvMobileNumber"
                        runat="server"
                        ControlToValidate="txtMobileNumber"
                        ErrorMessage="Mobile Number is required."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RequiredFieldValidator>

                    <asp:RegularExpressionValidator
                        ID="revMobileNumber"
                        runat="server"
                        ControlToValidate="txtMobileNumber"
                        ErrorMessage="Please enter a valid mobile number."
                        ValidationExpression="^\+?[0-9\s\-]{8,20}$"
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RegularExpressionValidator>
                </div>

                <!-- Gender -->
                <div class="registerField">
                    <span class="registerFieldLabel">Gender</span>

                    <asp:RadioButtonList
                        ID="rblGender"
                        runat="server"
                        CssClass="genderOptions"
                        RepeatDirection="Horizontal"
                        RepeatLayout="Flow">
                        <asp:ListItem Text="Male" Value="Male"></asp:ListItem>
                        <asp:ListItem Text="Female" Value="Female"></asp:ListItem>
                        <asp:ListItem Text="Prefer not to say" Value="Prefer not to say"></asp:ListItem>
                    </asp:RadioButtonList>

                    <asp:RequiredFieldValidator
                        ID="rfvGender"
                        runat="server"
                        ControlToValidate="rblGender"
                        InitialValue=""
                        ErrorMessage="Please select a gender option."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RequiredFieldValidator>
                </div>

                <!-- Password -->
                <div class="registerField">
                    <asp:Label
                        ID="lblPassword"
                        runat="server"
                        AssociatedControlID="txtPassword"
                        Text="Password">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtPassword"
                        runat="server"
                        CssClass="registerTextbox"
                        TextMode="Password"
                        MaxLength="100"
                        placeholder="Create a strong password">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvPassword"
                        runat="server"
                        ControlToValidate="txtPassword"
                        ErrorMessage="Password is required."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RequiredFieldValidator>

                    <asp:RegularExpressionValidator
                        ID="revPassword"
                        runat="server"
                        ControlToValidate="txtPassword"
                        ErrorMessage="Password must be at least 8 characters and include uppercase, lowercase, number, and special character."
                        ValidationExpression="^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^*()_+\-=]).{8,100}$"
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RegularExpressionValidator>
                </div>

                <!-- Confirm Password -->
                <div class="registerField">
                    <asp:Label
                        ID="lblConfirmPassword"
                        runat="server"
                        AssociatedControlID="txtConfirmPassword"
                        Text="Confirm Password">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtConfirmPassword"
                        runat="server"
                        CssClass="registerTextbox"
                        TextMode="Password"
                        MaxLength="100"
                        placeholder="Re-enter your password">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvConfirmPassword"
                        runat="server"
                        ControlToValidate="txtConfirmPassword"
                        ErrorMessage="Confirm Password is required."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:RequiredFieldValidator>

                    <asp:CompareValidator
                        ID="cvConfirmPassword"
                        runat="server"
                        ControlToValidate="txtConfirmPassword"
                        ControlToCompare="txtPassword"
                        Operator="Equal"
                        Type="String"
                        ErrorMessage="Password and Confirm Password must match."
                        CssClass="fieldError"
                        Display="Dynamic"
                        ValidationGroup="RegisterGroup">
                    </asp:CompareValidator>
                </div>

            </div>

            <div class="passwordGuidance">
                <strong>Password requirements:</strong>
                At least 8 characters, including one uppercase letter, one lowercase
                letter, one number, and one special character.
            </div>

            <asp:Button
                ID="btnRegister"
                runat="server"
                Text="REGISTER"
                CssClass="registerButton"
                ValidationGroup="RegisterGroup"
                OnClick="btnRegister_Click" />

            <p class="loginRedirect">
                Already have an account?
                <asp:HyperLink
                    ID="lnkLogin"
                    runat="server"
                    NavigateUrl="~/Login.aspx">
                    Login here
                </asp:HyperLink>
            </p>

        </div>

    </div>

</asp:Content>