﻿<%@ Page Title="Easy Experiments"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="Easy.aspx.cs"
    Inherits="Easy" %>

<asp:Content ID="Content1" ContentPlaceHolderID="MainContent" runat="server">

<div class="pageHeader">
    <h1>🧪 Easy Chemistry Experiments</h1>
    <p>Perfect for beginners using simple household materials.</p>
    <div class="searchContainer">

    <input
        type="text"
        id="easySearch"
        class="searchBox"
        placeholder="🔍 Search Easy Experiments..."
        onkeyup="filterEasy()" />

</div>
</div>

<div class="experimentContainer">

    <!-- Acid & Base -->
    <div class="experimentCard searchableEasy"
     data-name="acid acid-base base reaction vinegar baking soda">

        <img src="Images/acid-base.jpg" class="experimentImage" />

        <div class="cardContent">

            <h3>Acid &amp; Base Reaction</h3>

            <p>
                Learn how acids react with bases to produce carbon dioxide gas.
            </p>

            <asp:Button
                ID="btnAcid"
                runat="server"
                Text="View Experiment"
                CssClass="experimentButton"
                PostBackUrl="~/ExperimentDetails.aspx?id=1" />

        </div>

    </div>

    <!-- Walking Water -->
    <div class="experimentCard searchableEasy"
     data-name="walking water capillary colourful colors">

        <img src="Images/walking-water.jpg" class="experimentImage" />

        <div class="cardContent">

            <h3>Walking Water</h3>

            <p>
                Discover capillary action through a colourful water experiment.
            </p>

            <asp:Button
                ID="btnWalking"
                runat="server"
                Text="View Experiment"
                CssClass="experimentButton"
                PostBackUrl="~/ExperimentDetails.aspx?id=2" />

        </div>

    </div>

    <!-- Invisible Ink -->
    <div class="experimentCard searchableEasy"
     data-name="invisible ink lemon heat message">

        <img src="Images/invisible-ink.jpg" class="experimentImage" />

        <div class="cardContent">

            <h3>Invisible Ink</h3>

            <p>
                Reveal hidden messages using lemon juice and heat.
            </p>

            <asp:Button
                ID="btnInk"
                runat="server"
                Text="View Experiment"
                CssClass="experimentButton"
                PostBackUrl="~/ExperimentDetails.aspx?id=3" />

        </div>

    </div>

</div>
<script>
    function filterEasy() {

        const input =
            document.getElementById("easySearch")
                .value
                .toLowerCase()
                .trim();

        const cards =
            document.getElementsByClassName("searchableEasy");

        for (let i = 0; i < cards.length; i++) {

            const text =
                cards[i].getAttribute("data-name").toLowerCase();

            cards[i].style.display =
                text.includes(input) ? "" : "none";
        }
    }
</script>
</asp:Content>