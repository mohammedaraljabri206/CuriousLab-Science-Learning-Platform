﻿<%@ Page Title="Theory Details"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="TheoryDetails.aspx.cs"
    Inherits="TheoryDetails" %>

<asp:Content
    ID="Content1"
    ContentPlaceHolderID="head"
    runat="server">
</asp:Content>

<asp:Content
    ID="Content2"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <section class="theoryDetailsPage">

        <asp:Label
            ID="lblDetailsMessage"
            runat="server"
            CssClass="theoryMessage">
        </asp:Label>

        <asp:Panel
            ID="pnlTheoryDetails"
            runat="server"
            Visible="false">

            <asp:HyperLink
                ID="lnkBackToTheory"
                runat="server"
                NavigateUrl="~/Theory.aspx"
                CssClass="theoryBackLink">

                ← Back to Chemistry Theory

            </asp:HyperLink>

            <div class="theoryDetailsHero">

                <div class="theoryDetailsText">

                    <span class="theoryLabel">
                        CHEMISTRY THEORY
                    </span>

                    <asp:Label
                        ID="lblTitle"
                        runat="server"
                        CssClass="theoryDetailsTitle">
                    </asp:Label>

                    <asp:Label
                        ID="lblShortDescription"
                        runat="server"
                        CssClass="theoryDetailsDescription">
                    </asp:Label>

                </div>

                <div class="theoryDetailsImageContainer">

                    <asp:Image
                        ID="imgTheoryDetails"
                        runat="server"
                        CssClass="theoryDetailsImage" />

                </div>

            </div>

            <div class="theoryDetailsContent">

                <section class="theoryContentSection">

                    <h2>Introduction</h2>

                    <asp:Label
                        ID="lblIntroduction"
                        runat="server"
                        CssClass="theoryParagraph">
                    </asp:Label>

                </section>

                <section class="theoryContentSection">

                    <h2>Key Concepts</h2>

                    <asp:BulletedList
                        ID="bltKeyConcepts"
                        runat="server"
                        CssClass="theoryList">
                    </asp:BulletedList>

                </section>

                <section class="theoryContentSection">

                    <h2>Real-Life Examples</h2>

                    <asp:BulletedList
                        ID="bltRealLifeExamples"
                        runat="server"
                        CssClass="theoryList">
                    </asp:BulletedList>

                </section>

                <asp:Panel
                    ID="pnlRelatedExperiment"
                    runat="server"
                    CssClass="relatedExperimentCard"
                    Visible="false">

                    <div>

                        <span class="theoryLabel">
                            RELATED ACTIVITY
                        </span>

                        <h2>Try a Related Experiment</h2>

                        <asp:Label
                            ID="lblRelatedExperiment"
                            runat="server"
                            CssClass="relatedExperimentTitle">
                        </asp:Label>

                    </div>

                    <asp:HyperLink
                        ID="lnkRelatedExperiment"
                        runat="server"
                        CssClass="theoryReadButton">

                        Start Experiment →

                    </asp:HyperLink>

                </asp:Panel>

            </div>

        </asp:Panel>

    </section>

</asp:Content>