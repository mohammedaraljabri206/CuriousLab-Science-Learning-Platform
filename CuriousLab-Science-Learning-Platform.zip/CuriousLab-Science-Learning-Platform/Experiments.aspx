﻿<%@ Page Title="Experiments"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="Experiments.aspx.cs"
    Inherits="Experiments" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="head"
    runat="server">
</asp:Content>

<asp:Content ID="Content2"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="experimentPage">

        <div class="pageHeader">
            <h1>Explore Chemistry Experiments</h1>
            <p>
                Select a difficulty level and begin exploring safe and
                educational chemistry experiments.
            </p>
        </div>

        <div class="categories">

            <div class="categoryCard">

                <img src="Images/easy.png"
                    alt="Easy chemistry experiments"
                    class="categoryImage" />

                <div class="cardBody">

                    <h3 class="easyTitle">Easy Experiments</h3>

                    <p>
                        Beginner-friendly experiments using simple household
                        materials.
                    </p>

                    <asp:Button
                        ID="btnEasy"
                        runat="server"
                        Text="View Easy Experiments"
                        CssClass="experimentButton"
                        PostBackUrl="~/Easy.aspx" />

                </div>

            </div>

            <div class="categoryCard">

                <img src="Images/Medium.png"
                    alt="Intermediate chemistry experiments"
                    class="categoryImage" />

                <div class="cardBody">

                    <h3 class="mediumTitle">
                        Intermediate Experiments
                    </h3>

                    <p>
                        More challenging experiments for students who already
                        understand basic chemistry concepts.
                    </p>

                    <asp:Button
                        ID="btnMedium"
                        runat="server"
                        Text="View Intermediate Experiments"
                        CssClass="experimentButton"
                        PostBackUrl="~/Intermediate.aspx" />

                </div>

            </div>

            <div class="categoryCard">

                <img src="Images/hard.png"
                    alt="Advanced chemistry experiments"
                    class="categoryImage" />

                <div class="cardBody">

                    <h3 class="hardTitle">Advanced Experiments</h3>

                    <p>
                        Advanced investigations that require additional care,
                        preparation and supervision.
                    </p>

                    <asp:Button
                        ID="btnHard"
                        runat="server"
                        Text="View Advanced Experiments"
                        CssClass="experimentButton"
                        PostBackUrl="~/Advanced.aspx" />

                </div>

            </div>

        </div>

    </div>

</asp:Content>