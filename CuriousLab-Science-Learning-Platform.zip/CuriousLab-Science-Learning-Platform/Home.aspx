﻿<%@ Page Title="" Language="C#" MasterPageFile="~/Master.master" AutoEventWireup="true"
    CodeFile="Home.aspx.cs" Inherits="Home" %>

<asp:Content ID="Content1" ContentPlaceHolderID="head" runat="server">
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="MainContent" runat="server">

    <div class="pageContainer">

        <!-- HERO SECTION -->
        <section class="homeHero">

            <div class="heroText">

    <asp:Label
        ID="lblWelcome"
        runat="server"
        CssClass="welcomeMessage"
        Text="Welcome to CuriousLab">
    </asp:Label>

    <span class="heroLabel">
        LEARN • EXPERIMENT • DISCOVER
    </span>

    <h1>
        Explore Chemistry Through
        <span>Safe Home Experiments</span>
    </h1>

                <p>
                    CuriousLab is an interactive learning platform designed to help
                    students understand fundamental chemistry concepts through
                    step-by-step experiments, theory materials, quizzes, and practical
                    scientific observations.
                </p>

                <div class="heroButtons">

                    <asp:HyperLink
                        ID="lnkExploreExperiments"
                        runat="server"
                        NavigateUrl="~/Experiments.aspx"
                        CssClass="primaryButton">
                        Explore Experiments
                    </asp:HyperLink>

                    <asp:HyperLink
                        ID="lnkReadTheory"
                        runat="server"
                        NavigateUrl="~/Theory.aspx"
                        CssClass="secondaryButton">
                        Read Chemistry Theory
                    </asp:HyperLink>

                </div>

            </div>

            <div class="heroImage">

                <asp:Image
                    ID="imgHero"
                    runat="server"
                    ImageUrl="~/Images/home-chemistry.jpg"
                    AlternateText="Chemistry experiment equipment displayed on a laboratory table" />

            </div>

        </section>


        <!-- INTRODUCTION SECTION -->
        <section class="homeIntroduction">

            <div class="sectionHeading">

                <span>ABOUT CURIOUSLAB</span>

                <h2>Making Chemistry Simple, Practical and Engaging</h2>

                <p>
                    CuriousLab connects classroom theory with practical activities.
                    Students can browse chemistry experiments according to difficulty,
                    follow clear procedures, learn safety precautions, complete quizzes,
                    and provide feedback about their learning experience.
                </p>

            </div>

        </section>


        <!-- FEATURE CARDS -->
        <section class="homeFeatures">

            <article class="featureCard">

                <div class="featureIcon">🧪</div>

                <h3>Home Experiments</h3>

                <p>
                    Explore beginner, intermediate, and advanced chemistry experiments
                    using clear instructions and accessible materials.
                </p>

                <asp:HyperLink
                    ID="lnkFeatureExperiments"
                    runat="server"
                    NavigateUrl="~/Experiments.aspx"
                    CssClass="cardLink">
                    View Experiments →
                </asp:HyperLink>

            </article>


            <article class="featureCard">

                <div class="featureIcon">📘</div>

                <h3>Chemistry Theory</h3>

                <p>
                    Study important scientific concepts, explanations, formulas, and
                    safety information before conducting each experiment.
                </p>

                <asp:HyperLink
                    ID="lnkFeatureTheory"
                    runat="server"
                    NavigateUrl="~/Theory.aspx"
                    CssClass="cardLink">
                    Read Theory →
                </asp:HyperLink>

            </article>


            <article class="featureCard">

                <div class="featureIcon">📝</div>

                <h3>Self-Assessment Quiz</h3>

                <p>
                    Test your understanding through interactive chemistry questions
                    and receive immediate results after submitting your answers.
                </p>

                <asp:HyperLink
                    ID="lnkFeatureQuiz"
                    runat="server"
                    NavigateUrl="~/Quiz.aspx"
                    CssClass="cardLink">
                    Take a Quiz →
                </asp:HyperLink>

            </article>

        </section>


        <!-- DIFFICULTY SECTION -->
        <section class="difficultySection">

            <div class="difficultyHeading">

                <span>CHOOSE YOUR LEVEL</span>

                <h2>Experiments for Every Learning Stage</h2>

                <p>
                    Select a level that matches your current chemistry knowledge and
                    practical confidence.
                </p>

            </div>

            <div class="difficultyGrid">

                <article class="difficultyCard">

                    <div class="difficultyNumber">01</div>

                    <h3>Easy</h3>

                    <p>
                        Safe and simple experiments designed for beginners using common
                        household materials.
                    </p>

                    <asp:HyperLink
                        ID="lnkEasy"
                        runat="server"
                        NavigateUrl="~/Easy.aspx"
                        CssClass="difficultyLink">
                        View Easy Experiments
                    </asp:HyperLink>

                </article>


                <article class="difficultyCard">

                    <div class="difficultyNumber">02</div>

                    <h3>Intermediate</h3>

                    <p>
                        More challenging activities that develop observation,
                        measurement, and scientific reasoning skills.
                    </p>

                    <asp:HyperLink
                        ID="lnkIntermediate"
                        runat="server"
                        NavigateUrl="~/Intermediate.aspx"
                        CssClass="difficultyLink">
                        View Intermediate Experiments
                    </asp:HyperLink>

                </article>


                <article class="difficultyCard">

                    <div class="difficultyNumber">03</div>

                    <h3>Hard</h3>

                    <p>
                        Advanced chemistry activities for learners who are ready to
                        explore more complex scientific concepts.
                    </p>

                    <asp:HyperLink
                        ID="lnkHard"
                        runat="server"
                        NavigateUrl="~/Advanced.aspx"
                        CssClass="difficultyLink">
                        View Advanced Experiments
                    </asp:HyperLink>

                </article>

            </div>

        </section>


        <!-- CALL TO ACTION -->
        <section class="homeCallToAction">

            <div>

                <span>READY TO BEGIN?</span>

                <h2>Start Your CuriousLab Learning Journey</h2>

                <p>
                    Create an account to access experiments, quizzes, progress
                    tracking, feedback features, and your personal learning profile.
                </p>

            </div>

            <asp:HyperLink
                ID="lnkCreateAccount"
                runat="server"
                NavigateUrl="~/Register.aspx"
                CssClass="ctaButton">
                Create Account
            </asp:HyperLink>

        </section>

    </div>

</asp:Content>