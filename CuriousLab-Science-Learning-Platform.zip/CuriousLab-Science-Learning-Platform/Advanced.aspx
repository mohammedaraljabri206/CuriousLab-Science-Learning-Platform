﻿<%@ Page Title="Advanced Experiments"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="Advanced.aspx.cs"
    Inherits="Advanced" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="pageHeader">

        <h1>🔴 Advanced Chemistry Experiments</h1>

        <p>
            Challenge yourself with advanced chemistry investigations.
        </p>

        <div class="searchContainer">

            <input
                type="text"
                id="advancedSearch"
                class="searchBox"
                placeholder="🔍 Search Advanced Experiments..."
                onkeyup="filterAdvanced()" />

        </div>

    </div>

    <div class="experimentContainer">

        <!-- Crystal Growing -->
        <div class="experimentCard searchableAdvanced"
            data-name="crystal growing crystallisation borax hot water pipe cleaner">

            <img
                src="Images/crystal-growing.jpg"
                class="experimentImage"
                alt="Crystal Growing experiment" />

            <div class="cardContent">

                <h3>Crystal Growing</h3>

                <p>
                    Grow beautiful crystals while learning about crystallisation.
                </p>

                <asp:Button
                    ID="btnCrystal"
                    runat="server"
                    Text="View Experiment"
                    CssClass="experimentButton"
                    PostBackUrl="~/ExperimentDetails.aspx?id=7" />

            </div>

        </div>

        <!-- Electrolysis -->
        <div class="experimentCard searchableAdvanced"
            data-name="electrolysis water electricity hydrogen oxygen battery electrodes">

            <img
                src="Images/electrolysis.jpg"
                class="experimentImage"
                alt="Electrolysis of Water experiment" />

            <div class="cardContent">

                <h3>Electrolysis of Water</h3>

                <p>
                    Use electricity to split water into hydrogen and oxygen.
                </p>

                <asp:Button
                    ID="btnElectrolysis"
                    runat="server"
                    Text="View Experiment"
                    CssClass="experimentButton"
                    PostBackUrl="~/ExperimentDetails.aspx?id=8" />

            </div>

        </div>

        <!-- Copper Plating -->
        <div class="experimentCard searchableAdvanced"
            data-name="copper plating electroplating metal object copper sulfate battery">

            <img
                src="Images/copper-plating.jpg"
                class="experimentImage"
                alt="Copper Plating experiment" />

            <div class="cardContent">

                <h3>Copper Plating</h3>

                <p>
                    Learn how electroplating deposits copper onto a metal object.
                </p>

                <asp:Button
                    ID="btnCopper"
                    runat="server"
                    Text="View Experiment"
                    CssClass="experimentButton"
                    PostBackUrl="~/ExperimentDetails.aspx?id=9" />

            </div>

        </div>

    </div>

    <script>
        function filterAdvanced() {

            const input =
                document.getElementById("advancedSearch")
                    .value
                    .toLowerCase()
                    .trim();

            const cards =
                document.getElementsByClassName(
                    "searchableAdvanced"
                );

            for (let i = 0; i < cards.length; i++) {

                const text =
                    cards[i].getAttribute("data-name").toLowerCase();

                cards[i].style.display =
                    text.includes(input) ? "" : "none";
            }
        }
    </script>

</asp:Content>