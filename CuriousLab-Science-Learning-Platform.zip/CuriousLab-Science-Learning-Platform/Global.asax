<%@ Application Language="C#" %>
<script runat="server">
    void Application_AcquireRequestState(object sender, EventArgs e)
    {
        if (Context.Session == null)
            return;

        string page = VirtualPathUtility.GetFileName(
            Request.AppRelativeCurrentExecutionFilePath).ToLowerInvariant();
        bool loggedIn = Session["UserID"] != null;

        if (loggedIn && (page == "login.aspx" || page == "register.aspx"))
        {
            string role = Convert.ToString(Session["Role"]);
            Response.Redirect(
                role.Equals("Admin", StringComparison.OrdinalIgnoreCase)
                    ? "~/AdminDashboard.aspx"
                    : "~/Home.aspx");
            return;
        }

        if (!loggedIn &&
            (page == "quiz.aspx" ||
             page == "feedback.aspx" ||
             page == "userprofile.aspx"))
        {
            Response.Redirect("~/Login.aspx?returnUrl=" +
                Server.UrlEncode(Request.RawUrl));
        }
    }
</script>
