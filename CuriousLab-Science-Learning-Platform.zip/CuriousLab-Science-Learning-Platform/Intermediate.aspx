﻿<%@ Page Title="Intermediate Experiments"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="Intermediate.aspx.cs"
    Inherits="Intermediate" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <div class="pageHeader">

        <h1>🟡 Intermediate Chemistry Experiments</h1>

        <p>
            Develop your chemistry knowledge with more exciting experiments.
        </p>

        <div class="searchContainer">

            <input
                type="text"
                id="intermediateSearch"
                class="searchBox"
                placeholder="🔍 Search Intermediate Experiments..."
                onkeyup="filterIntermediate()" />

        </div>

    </div>

    <div class="experimentContainer">

        <!-- Elephant Toothpaste -->
        <div class="experimentCard searchableIntermediate"
            data-name="elephant toothpaste foam eruption hydrogen peroxide yeast chemical reaction">

            <img
                src="Images/Elephant-Toothpaste.png"
                class="experimentImage"
                alt="Elephant Toothpaste experiment" />

            <div class="cardContent">

                <h3>Elephant Toothpaste</h3>

                <p>
                    Create a spectacular foam eruption using a chemical reaction.
                </p>

                <asp:Button
                    ID="btnElephant"
                    runat="server"
                    Text="View Experiment"
                    CssClass="experimentButton"
                    PostBackUrl="~/ExperimentDetails.aspx?id=4" />

            </div>

        </div>

        <!-- Rainbow Milk -->
        <div class="experimentCard searchableIntermediate"
            data-name="rainbow milk soap surface tension colours food colouring">

            <img
                src="Images/rainbow-milk.jpg"
                class="experimentImage"
                alt="Rainbow Milk experiment" />

            <div class="cardContent">

                <h3>Rainbow Milk</h3>

                <p>
                    Discover how soap changes the surface tension of milk.
                </p>

                <asp:Button
                    ID="btnRainbow"
                    runat="server"
                    Text="View Experiment"
                    CssClass="experimentButton"
                    PostBackUrl="~/ExperimentDetails.aspx?id=5" />

            </div>

        </div>

        <!-- Lava Lamp -->
        <div class="experimentCard searchableIntermediate"
            data-name="lava lamp oil water food colouring effervescent tablet bubbles">

            <img
                src="Images/lava-lamp.jpg"
                class="experimentImage"
                alt="Lava Lamp experiment" />

            <div class="cardContent">

                <h3>Lava Lamp</h3>

                <p>
                    Build your own colourful lava lamp using simple ingredients.
                </p>

                <asp:Button
                    ID="btnLava"
                    runat="server"
                    Text="View Experiment"
                    CssClass="experimentButton"
                    PostBackUrl="~/ExperimentDetails.aspx?id=6" />

            </div>

        </div>

    </div>

    <script>
        function filterIntermediate() {

            const input =
                document.getElementById("intermediateSearch")
                    .value
                    .toLowerCase()
                    .trim();

            const cards =
                document.getElementsByClassName(
                    "searchableIntermediate"
                );

            for (let i = 0; i < cards.length; i++) {

                const text =
                    cards[i].getAttribute("data-name").toLowerCase();

                cards[i].style.display =
                    text.includes(input) ? "" : "none";
            }
        }
    </script>

</asp:Content>