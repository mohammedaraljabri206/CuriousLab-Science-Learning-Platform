using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI.WebControls;

public partial class Quiz : Member3PageBase
{
    private string ConnectionString
    {
        get { return ConfigurationManager.ConnectionStrings["CuriousLabConnection"].ConnectionString; }
    }

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack) LoadQuestions();
    }

    private void LoadQuestions()
    {
        const string sql = @"SELECT TOP 5 QuestionID, QuestionText, OptionA, OptionB,
            OptionC, OptionD, CorrectOption, Explanation
            FROM dbo.QuizQuestions WHERE IsActive=1 ORDER BY NEWID()";
        var table = new DataTable();
        using (var adapter = new SqlDataAdapter(sql, ConnectionString)) adapter.Fill(table);
        rptQuestions.DataSource = table;
        rptQuestions.DataBind();
        btnSubmitQuiz.Visible = table.Rows.Count > 0;
        if (table.Rows.Count == 0) lblQuizMessage.Text = "No active quiz questions are available.";
    }

    protected void rptQuestions_ItemDataBound(object sender, RepeaterItemEventArgs e)
    {
        if (e.Item.ItemType != ListItemType.Item &&
            e.Item.ItemType != ListItemType.AlternatingItem) return;
        var row = (DataRowView)e.Item.DataItem;
        var answers = (RadioButtonList)e.Item.FindControl("rblAnswers");
        answers.Items.Add(new ListItem("A. " + row["OptionA"], "A"));
        answers.Items.Add(new ListItem("B. " + row["OptionB"], "B"));
        answers.Items.Add(new ListItem("C. " + row["OptionC"], "C"));
        answers.Items.Add(new ListItem("D. " + row["OptionD"], "D"));
    }

    protected void cvAnswer_ServerValidate(object source, ServerValidateEventArgs args)
    {
        var validator = (CustomValidator)source;
        var answers = (RadioButtonList)validator.NamingContainer.FindControl("rblAnswers");
        args.IsValid = answers != null && !string.IsNullOrEmpty(answers.SelectedValue);
    }

    protected void btnSubmitQuiz_Click(object sender, EventArgs e)
    {
        Page.Validate("QuizGroup");
        if (!Page.IsValid) { lblQuizMessage.Text = "Please answer every question."; return; }
        int score = 0, total = 0;
        using (var connection = new SqlConnection(ConnectionString))
        {
            connection.Open();
            foreach (RepeaterItem item in rptQuestions.Items)
            {
                int questionID = int.Parse(((HiddenField)item.FindControl("hidQuestionID")).Value);
                var answers = (RadioButtonList)item.FindControl("rblAnswers");
                string correct = ((HiddenField)item.FindControl("hidCorrect")).Value;
                bool isCorrect = answers.SelectedValue == correct;
                if (isCorrect) score++;
                total++;
                using (var command = new SqlCommand(@"INSERT dbo.QuizAttempts
                    (UserID,QuestionID,SelectedOption,IsCorrect,AttemptDate)
                    VALUES(@UserID,@QuestionID,@SelectedOption,@IsCorrect,GETDATE())", connection))
                {
                    command.Parameters.Add("@UserID", SqlDbType.Int).Value = Session["UserID"];
                    command.Parameters.Add("@QuestionID", SqlDbType.Int).Value = questionID;
                    command.Parameters.Add("@SelectedOption", SqlDbType.NChar, 1).Value = answers.SelectedValue;
                    command.Parameters.Add("@IsCorrect", SqlDbType.Bit).Value = isCorrect;
                    command.ExecuteNonQuery();
                }
                var panel = (Panel)item.FindControl("pnlExplanation");
                var label = (Label)item.FindControl("lblExplanation");
                panel.Visible = true;
                panel.CssClass += isCorrect ? " correct" : " incorrect";
                label.Text = (isCorrect ? "Correct. " : "Correct answer: " + correct + ". ") +
                    Server.HtmlEncode(((HiddenField)item.FindControl("hidExplanation")).Value);
                answers.Enabled = false;
            }
        }
        lblQuizMessage.Text = "Your score is " + score + " out of " + total + ".";
        btnSubmitQuiz.Visible = false;
        btnTryAgain.Visible = true;
    }

    protected void btnTryAgain_Click(object sender, EventArgs e)
    {
        btnTryAgain.Visible = false;
        lblQuizMessage.Text = "";
        LoadQuestions();
    }
}
