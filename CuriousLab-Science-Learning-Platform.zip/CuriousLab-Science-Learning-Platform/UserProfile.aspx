﻿<%@ Page Title="My Profile"
    Language="C#"
    MasterPageFile="~/Master.master"
    AutoEventWireup="true"
    CodeFile="UserProfile.aspx.cs"
    Inherits="UserProfile" %>

<asp:Content ID="Content1"
    ContentPlaceHolderID="MainContent"
    runat="server">

    <section class="profilePage">

        <div class="profileHeader">

            <div class="profileAvatar">
                <asp:Label
                    ID="lblInitials"
                    runat="server"
                    Text="CL">
                </asp:Label>
            </div>

            <div class="profileHeading">

                <p class="profileEyebrow">
                    STUDENT ACCOUNT
                </p>

                <h1>My Profile</h1>

                <p>
                    View and update your CuriousLab account information.
                </p>

            </div>

        </div>

        <asp:Label
            ID="lblProfileMessage"
            runat="server"
            EnableViewState="false">
        </asp:Label>

        <div class="profileCard">

            <div class="profileSectionHeading">

                <div>
                    <h2>Personal Information</h2>

                    <p>
                        Keep your account details accurate and up to date.
                    </p>
                </div>

                <asp:Button
                    ID="btnEdit"
                    runat="server"
                    Text="Edit Profile"
                    CssClass="profileEditButton"
                    CausesValidation="false"
                    OnClick="btnEdit_Click" />

            </div>

            <div class="profileGrid">

                <div class="profileField">

                    <asp:Label
                        ID="lblFullNameCaption"
                        runat="server"
                        AssociatedControlID="txtFullName"
                        Text="Full Name">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtFullName"
                        runat="server"
                        CssClass="profileInput"
                        MaxLength="100"
                        Enabled="false">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvFullName"
                        runat="server"
                        ControlToValidate="txtFullName"
                        ErrorMessage="Full name is required."
                        CssClass="profileValidation"
                        ValidationGroup="ProfileGroup"
                        Display="Dynamic">
                    </asp:RequiredFieldValidator>

                </div>

                <div class="profileField">

                    <asp:Label
                        ID="lblEmailCaption"
                        runat="server"
                        AssociatedControlID="txtEmail"
                        Text="Email Address">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtEmail"
                        runat="server"
                        CssClass="profileInput profileReadOnly"
                        ReadOnly="true">
                    </asp:TextBox>

                </div>

                <div class="profileField">

                    <asp:Label
                        ID="lblDateOfBirthCaption"
                        runat="server"
                        AssociatedControlID="txtDateOfBirth"
                        Text="Date of Birth">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtDateOfBirth"
                        runat="server"
                        CssClass="profileInput"
                        TextMode="Date"
                        Enabled="false">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvDateOfBirth"
                        runat="server"
                        ControlToValidate="txtDateOfBirth"
                        ErrorMessage="Date of birth is required."
                        CssClass="profileValidation"
                        ValidationGroup="ProfileGroup"
                        Display="Dynamic">
                    </asp:RequiredFieldValidator>

                    <asp:CustomValidator
                        ID="cvDateOfBirth"
                        runat="server"
                        ControlToValidate="txtDateOfBirth"
                        ErrorMessage="Enter a valid date of birth."
                        CssClass="profileValidation"
                        ValidationGroup="ProfileGroup"
                        Display="Dynamic"
                        OnServerValidate="cvDateOfBirth_ServerValidate">
                    </asp:CustomValidator>

                </div>

                <div class="profileField">

                    <asp:Label
                        ID="lblMobileCaption"
                        runat="server"
                        AssociatedControlID="txtMobileNumber"
                        Text="Mobile Number">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtMobileNumber"
                        runat="server"
                        CssClass="profileInput"
                        MaxLength="20"
                        Enabled="false">
                    </asp:TextBox>

                    <asp:RequiredFieldValidator
                        ID="rfvMobileNumber"
                        runat="server"
                        ControlToValidate="txtMobileNumber"
                        ErrorMessage="Mobile number is required."
                        CssClass="profileValidation"
                        ValidationGroup="ProfileGroup"
                        Display="Dynamic">
                    </asp:RequiredFieldValidator>

                </div>

                <div class="profileField">

                    <asp:Label
                        ID="lblGenderCaption"
                        runat="server"
                        AssociatedControlID="ddlGender"
                        Text="Gender">
                    </asp:Label>

                    <asp:DropDownList
                        ID="ddlGender"
                        runat="server"
                        CssClass="profileInput"
                        Enabled="false">

                        <asp:ListItem
                            Text="Select gender"
                            Value="">
                        </asp:ListItem>

                        <asp:ListItem
                            Text="Male"
                            Value="Male">
                        </asp:ListItem>

                        <asp:ListItem
                            Text="Female"
                            Value="Female">
                        </asp:ListItem>

                        <asp:ListItem
                            Text="Prefer not to say"
                            Value="Prefer not to say">
                        </asp:ListItem>

                    </asp:DropDownList>

                    <asp:RequiredFieldValidator
                        ID="rfvGender"
                        runat="server"
                        ControlToValidate="ddlGender"
                        InitialValue=""
                        ErrorMessage="Please select a gender."
                        CssClass="profileValidation"
                        ValidationGroup="ProfileGroup"
                        Display="Dynamic">
                    </asp:RequiredFieldValidator>

                </div>

                <div class="profileField">

                    <asp:Label
                        ID="lblRoleCaption"
                        runat="server"
                        AssociatedControlID="txtRole"
                        Text="Account Role">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtRole"
                        runat="server"
                        CssClass="profileInput profileReadOnly"
                        ReadOnly="true">
                    </asp:TextBox>

                </div>

                <div class="profileField profileWideField">

                    <asp:Label
                        ID="lblCreatedDateCaption"
                        runat="server"
                        AssociatedControlID="txtCreatedDate"
                        Text="Member Since">
                    </asp:Label>

                    <asp:TextBox
                        ID="txtCreatedDate"
                        runat="server"
                        CssClass="profileInput profileReadOnly"
                        ReadOnly="true">
                    </asp:TextBox>

                </div>

            </div>

            <asp:Panel
                ID="pnlProfileActions"
                runat="server"
                CssClass="profileActions"
                Visible="false">

                <asp:Button
                    ID="btnSave"
                    runat="server"
                    Text="Save Changes"
                    CssClass="profileSaveButton"
                    ValidationGroup="ProfileGroup"
                    OnClick="btnSave_Click" />

                <asp:Button
                    ID="btnCancel"
                    runat="server"
                    Text="Cancel"
                    CssClass="profileCancelButton"
                    CausesValidation="false"
                    OnClick="btnCancel_Click" />

            </asp:Panel>

        </div>

    </section>

</asp:Content>