﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Master : System.Web.UI.MasterPage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        UpdateNavigation();
    }

    private void UpdateNavigation()
    {
        bool isLoggedIn = Session["UserID"] != null;

        bool isAdmin =
            isLoggedIn &&
            string.Equals(
                Convert.ToString(Session["Role"]),
                "Admin",
                StringComparison.OrdinalIgnoreCase);

        // Registered-user pages
        lnkQuiz.Visible = isLoggedIn;
        lnkFeedback.Visible = isLoggedIn;
        lnkProfile.Visible = isLoggedIn;

        // Administrator-only page
        lnkAdmin.Visible = isAdmin;

        // Login/logout button
        btnLoginLogout.Text = isLoggedIn
            ? "LOGOUT"
            : "LOGIN";
    }

    protected void btnLoginLogout_Click(
        object sender,
        EventArgs e)
    {
        if (Session["UserID"] != null)
        {
            Session.Clear();
            Session.Abandon();

            Response.Redirect(
                "~/Home.aspx",
                false);
        }
        else
        {
            Response.Redirect(
                "~/Login.aspx",
                false);
        }

        Context.ApplicationInstance
            .CompleteRequest();
    }
}