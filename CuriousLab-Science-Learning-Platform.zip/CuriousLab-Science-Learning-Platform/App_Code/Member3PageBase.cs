using System;
using System.Web.UI;

public class Member3PageBase : Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        if (Session["UserID"] == null)
            Response.Redirect("~/Login.aspx?returnUrl=" + Server.UrlEncode(Request.RawUrl));
    }
}
