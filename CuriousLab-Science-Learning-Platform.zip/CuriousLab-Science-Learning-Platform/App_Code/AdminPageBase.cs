using System;
using System.Web.UI;

public class AdminPageBase : Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        if (Session["UserID"] == null)
        {
            Response.Redirect("~/Login.aspx?returnUrl=" +
                Server.UrlEncode(Request.RawUrl));
        }

        if (!string.Equals(Convert.ToString(Session["Role"]), "Admin",
            StringComparison.OrdinalIgnoreCase))
        {
            Response.Redirect("~/Home.aspx?denied=1");
        }
    }
}

public class MemberPageBase : Page
{
    protected override void OnInit(EventArgs e)
    {
        base.OnInit(e);
        if (Session["UserID"] == null)
            Response.Redirect("~/Login.aspx?returnUrl=" +
                Server.UrlEncode(Request.RawUrl));
    }
}
