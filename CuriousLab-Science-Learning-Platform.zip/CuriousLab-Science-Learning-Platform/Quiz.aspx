<%@ Page Title="Chemistry Quiz" Language="C#" MasterPageFile="~/Master.master"
    AutoEventWireup="true" CodeFile="Quiz.aspx.cs" Inherits="Quiz" %>
<asp:Content ID="QuizHead" ContentPlaceHolderID="head" runat="server">
 <link href="Content/Member3.css" rel="stylesheet" />
</asp:Content>
<asp:Content ID="QuizContent" ContentPlaceHolderID="MainContent" runat="server">
 <section class="member3-shell">
  <span class="member3-kicker">SELF-ASSESSMENT</span>
  <h1>Chemistry Knowledge Quiz</h1>
  <p>Answer every question, then submit to see your score and explanations.</p>
  <asp:Label ID="lblQuizMessage" runat="server" CssClass="member3-message" />
  <asp:Repeater ID="rptQuestions" runat="server" OnItemDataBound="rptQuestions_ItemDataBound">
   <ItemTemplate>
    <article class="quiz-card">
     <asp:HiddenField ID="hidQuestionID" runat="server" Value='<%# Eval("QuestionID") %>' />
     <asp:HiddenField ID="hidCorrect" runat="server" Value='<%# Eval("CorrectOption") %>' />
     <asp:HiddenField ID="hidExplanation" runat="server" Value='<%# Eval("Explanation") %>' />
     <h2><%# Container.ItemIndex + 1 %>. <%#: Eval("QuestionText") %></h2>
     <asp:RadioButtonList ID="rblAnswers" runat="server" CssClass="quiz-answer-list" />
     <asp:CustomValidator ID="cvAnswer" runat="server" ValidationGroup="QuizGroup"
        ErrorMessage="Please select an answer." CssClass="member3-error"
        OnServerValidate="cvAnswer_ServerValidate" />
     <asp:Panel ID="pnlExplanation" runat="server" Visible="false" CssClass="quiz-explanation">
      <asp:Label ID="lblExplanation" runat="server" />
     </asp:Panel>
    </article>
   </ItemTemplate>
  </asp:Repeater>
  <asp:Button ID="btnSubmitQuiz" runat="server" Text="Submit quiz"
      CssClass="member3-primary" ValidationGroup="QuizGroup" OnClick="btnSubmitQuiz_Click" />
  <asp:Button ID="btnTryAgain" runat="server" Text="Try another quiz"
      CssClass="member3-secondary" CausesValidation="false" Visible="false"
      OnClick="btnTryAgain_Click" />
 </section>
</asp:Content>
