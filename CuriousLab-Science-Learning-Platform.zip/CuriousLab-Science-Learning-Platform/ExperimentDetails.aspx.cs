﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Web.UI;


public partial class ExperimentDetails : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadExperiment();
        }
    }

    private void LoadExperiment()
    {
        int experimentID;

        if (!int.TryParse(Request.QueryString["id"], out experimentID))
        {
            ShowError("The selected experiment is invalid.");
            return;
        }

        string connectionString =
            ConfigurationManager
                .ConnectionStrings["CuriousLabConnection"]
                .ConnectionString;

        string sql = @"
            SELECT
                ExperimentName,
                TimeRequired,
                Materials,
                ProcedureSteps,
                Safety,
                Explanation,
                ExpectedResult,
                Image
            FROM dbo.Experiments
            WHERE ExperimentID = @ExperimentID";

        using (SqlConnection connection =
            new SqlConnection(connectionString))
        using (SqlCommand command =
            new SqlCommand(sql, connection))
        {
            command.Parameters.AddWithValue(
                "@ExperimentID",
                experimentID);

            connection.Open();

            using (SqlDataReader reader = command.ExecuteReader())
            {
                if (!reader.Read())
                {
                    ShowError("The requested experiment was not found.");
                    return;
                }

                lblTitle.Text =
                    Server.HtmlEncode(
                        reader["ExperimentName"].ToString());

                lblTime.Text =
                    Server.HtmlEncode(
                        reader["TimeRequired"].ToString());

                lblMaterials.Text =
                    Server.HtmlEncode(
                        reader["Materials"].ToString());

                lblProcedure.Text =
                    Server.HtmlEncode(
                        reader["ProcedureSteps"].ToString());

                lblSafety.Text =
                    Server.HtmlEncode(
                        reader["Safety"].ToString());

                lblExplanation.Text =
                    Server.HtmlEncode(
                        reader["Explanation"].ToString());

                lblResult.Text =
                    Server.HtmlEncode(
                        reader["ExpectedResult"].ToString());

                string imageFile =
                    reader["Image"].ToString();

                imgExperiment.ImageUrl =
                    "~/Images/" + imageFile;

                imgExperiment.AlternateText =
                    reader["ExperimentName"].ToString();
            }
        }

        SetProcedureNote(experimentID);
    }

    private void SetProcedureNote(int experimentID)
    {
        switch (experimentID)
        {
            case 1:
                lblProcedureNote.Text =
                    "Prepare a clean and stable workspace before starting. " +
                    "Pour the vinegar into the container and gradually add " +
                    "the baking soda. Observe the bubbles and foam produced " +
                    "when carbon dioxide gas is released. Record the speed " +
                    "and appearance of the reaction before safely cleaning " +
                    "the equipment.";
                break;

            case 2:
                lblProcedureNote.Text =
                    "Arrange the cups in order and connect them using folded " +
                    "paper towels. Add coloured water to the required cups " +
                    "and observe how the water travels through the towels by " +
                    "capillary action. Record the direction, colour changes " +
                    "and time required for the water to move.";
                break;

            case 3:
                lblProcedureNote.Text =
                    "Write a message using lemon juice and allow the paper " +
                    "to dry completely. Under adult or teacher supervision, " +
                    "gently warm the paper and observe the hidden message " +
                    "appearing as the lemon juice oxidises.";
                break;

            case 4:
                lblProcedureNote.Text =
                    "Prepare the workspace and wear the required safety " +
                    "equipment. Mix the hydrogen peroxide, dish soap and " +
                    "food colouring, then add the yeast mixture last. Step " +
                    "back and observe the rapid foam eruption caused by the " +
                    "release of oxygen gas.";
                break;

            case 5:
                lblProcedureNote.Text =
                    "Pour milk into a shallow plate and place several drops " +
                    "of food colouring on its surface. Touch the centre with " +
                    "a cotton bud dipped in dish soap. Observe the colours " +
                    "moving as the soap changes the milk's surface tension.";
                break;

            case 6:
                lblProcedureNote.Text =
                    "Fill the bottle partly with water, then add vegetable " +
                    "oil and food colouring. Add part of an effervescent " +
                    "tablet and observe coloured bubbles moving through the " +
                    "oil as carbon dioxide gas is produced.";
                break;

            case 7:
                lblProcedureNote.Text =
                    "Dissolve the required material in hot water and suspend " +
                    "the pipe cleaner in the solution. Leave the container " +
                    "undisturbed and record changes in the size and shape of " +
                    "the crystals as the solution cools.";
                break;

            case 8:
                lblProcedureNote.Text =
                    "Assemble the low-voltage electrolysis apparatus and " +
                    "check all connections before switching it on. Observe " +
                    "the gas bubbles forming at both electrodes. Disconnect " +
                    "the power supply before dismantling the apparatus.";
                break;

            case 9:
                lblProcedureNote.Text =
                    "Clean the metal object and connect the circuit correctly " +
                    "before placing the object and copper strip into the " +
                    "solution. Observe the copper coating forming, then " +
                    "disconnect the power and rinse the object safely.";
                break;

            default:
                lblProcedureNote.Text = string.Empty;
                break;
        }
    }

    private void ShowError(string message)
    {
        lblTitle.Text = message;
        lblTime.Text = string.Empty;
        lblMaterials.Text = string.Empty;
        lblProcedure.Text = string.Empty;
        lblProcedureNote.Text = string.Empty;
        lblSafety.Text = string.Empty;
        lblExplanation.Text = string.Empty;
        lblResult.Text = string.Empty;
        imgExperiment.Visible = false;
    }
}