﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Configuration;
using System.Data;
using System.Data.SqlClient;

public partial class TheoryDetails : System.Web.UI.Page
{
    private readonly string connectionString =
        ConfigurationManager
            .ConnectionStrings["CuriousLabConnection"]
            .ConnectionString;

    protected void Page_Load(
        object sender,
        EventArgs e)
    {
        if (!IsPostBack)
        {
            LoadTheoryDetails();
        }
    }

    private void LoadTheoryDetails()
    {
        int theoryID;

        if (!int.TryParse(
            Request.QueryString["id"],
            out theoryID))
        {
            ShowError(
                "The requested theory topic is invalid.");

            return;
        }

        const string query =
            @"SELECT
                  T.TheoryID,
                  T.Title,
                  T.ShortDescription,
                  T.Introduction,
                  T.KeyConcepts,
                  T.RealLifeExamples,
                  T.ImagePath,
                  T.RelatedExperimentID,
                  E.ExperimentName AS RelatedExperimentTitle
              FROM dbo.TheoryTopics T
              LEFT JOIN dbo.Experiments E
                  ON T.RelatedExperimentID = E.ExperimentID
              WHERE T.TheoryID = @TheoryID
                AND T.IsActive = 1";

        try
        {
            using (SqlConnection connection =
                   new SqlConnection(connectionString))
            using (SqlCommand command =
                   new SqlCommand(query, connection))
            {
                command.Parameters.Add(
                    "@TheoryID",
                    SqlDbType.Int).Value =
                    theoryID;

                connection.Open();

                using (SqlDataReader reader =
                       command.ExecuteReader())
                {
                    if (!reader.Read())
                    {
                        ShowError(
                            "The requested theory topic was not found.");

                        return;
                    }

                    lblTitle.Text =
                        Server.HtmlEncode(
                            reader["Title"].ToString());

                    lblShortDescription.Text =
                        Server.HtmlEncode(
                            reader["ShortDescription"]
                                .ToString());

                    lblIntroduction.Text =
                        Server.HtmlEncode(
                            reader["Introduction"]
                                .ToString());

                    imgTheoryDetails.ImageUrl =
                        reader["ImagePath"].ToString();

                    imgTheoryDetails.AlternateText =
                        reader["Title"].ToString();

                    BindList(
                        bltKeyConcepts,
                        reader["KeyConcepts"].ToString());

                    BindList(
                        bltRealLifeExamples,
                        reader["RealLifeExamples"]
                            .ToString());

                    if (reader["RelatedExperimentID"]
                        != DBNull.Value)
                    {
                        int experimentID =
                            Convert.ToInt32(
                                reader["RelatedExperimentID"]);

                        lblRelatedExperiment.Text =
                            Server.HtmlEncode(
                                reader["RelatedExperimentTitle"]
                                    .ToString());

                        lnkRelatedExperiment.NavigateUrl =
                            "~/ExperimentDetails.aspx?id=" +
                            experimentID;

                        pnlRelatedExperiment.Visible =
                            true;
                    }

                    pnlTheoryDetails.Visible = true;
                }
            }
        }
        catch (SqlException)
        {
            ShowError(
                "The theory topic could not be loaded. Please try again.");
        }
    }

    private static void BindList(
        BulletedList listControl,
        string values)
    {
        listControl.Items.Clear();

        if (string.IsNullOrWhiteSpace(values))
        {
            return;
        }

        string[] items =
            values.Split(
                new[] { '|' },
                StringSplitOptions.RemoveEmptyEntries);

        foreach (string item in items)
        {
            listControl.Items.Add(
                new ListItem(item.Trim()));
        }
    }

    private void ShowError(string message)
    {
        pnlTheoryDetails.Visible = false;

        lblDetailsMessage.Text =
            Server.HtmlEncode(message);

        lblDetailsMessage.CssClass =
            "theoryMessage theoryError";
    }
}