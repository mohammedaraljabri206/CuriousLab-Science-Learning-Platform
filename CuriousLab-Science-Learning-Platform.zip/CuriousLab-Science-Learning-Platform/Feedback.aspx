<%@ Page Title="Feedback" Language="C#" MasterPageFile="~/Master.master"
 AutoEventWireup="true" CodeFile="Feedback.aspx.cs" Inherits="Feedback" %>
<asp:Content ID="FeedbackHead" ContentPlaceHolderID="head" runat="server">
 <link href="Content/Member3.css" rel="stylesheet" />
</asp:Content>
<asp:Content ID="FeedbackContent" ContentPlaceHolderID="MainContent" runat="server">
 <section class="member3-shell">
  <span class="member3-kicker">HELP US IMPROVE</span><h1>Student Feedback</h1>
  <asp:ValidationSummary ID="vsFeedback" runat="server" ValidationGroup="FeedbackGroup"
      CssClass="member3-error" HeaderText="Please correct the following:" />
  <asp:Label ID="lblMessage" runat="server" CssClass="member3-message" />
  <div class="member3-form">
   <div class="member3-field"><label>Category</label>
    <asp:DropDownList ID="ddlCategory" runat="server" CssClass="member3-input">
     <asp:ListItem Value="">Select a category</asp:ListItem>
     <asp:ListItem>Website</asp:ListItem><asp:ListItem>Experiment</asp:ListItem>
     <asp:ListItem>Theory</asp:ListItem><asp:ListItem>Quiz</asp:ListItem><asp:ListItem>Other</asp:ListItem>
    </asp:DropDownList>
    <asp:RequiredFieldValidator runat="server" ControlToValidate="ddlCategory"
       InitialValue="" ValidationGroup="FeedbackGroup" ErrorMessage="Category is required." CssClass="member3-error" />
   </div>
   <div class="member3-field"><label>Subject</label>
    <asp:TextBox ID="txtSubject" runat="server" MaxLength="150" CssClass="member3-input" />
    <asp:RequiredFieldValidator runat="server" ControlToValidate="txtSubject"
       ValidationGroup="FeedbackGroup" ErrorMessage="Subject is required." CssClass="member3-error" />
   </div>
   <div class="member3-field"><label>Rating</label>
    <asp:TextBox ID="txtRating" runat="server" TextMode="Number" CssClass="member3-input" />
    <asp:RequiredFieldValidator runat="server" ControlToValidate="txtRating"
       ValidationGroup="FeedbackGroup" ErrorMessage="Rating is required." CssClass="member3-error" />
    <asp:RangeValidator runat="server" ControlToValidate="txtRating" Type="Integer"
       MinimumValue="1" MaximumValue="5" ValidationGroup="FeedbackGroup"
       ErrorMessage="Rating must be from 1 to 5." CssClass="member3-error" />
   </div>
   <div class="member3-field full"><label>Message</label>
    <asp:TextBox ID="txtFeedback" runat="server" TextMode="MultiLine" Rows="6"
       MaxLength="2000" CssClass="member3-input" />
    <asp:RequiredFieldValidator runat="server" ControlToValidate="txtFeedback"
       ValidationGroup="FeedbackGroup" ErrorMessage="Feedback message is required." CssClass="member3-error" />
    <asp:CustomValidator runat="server" ControlToValidate="txtFeedback"
       ValidationGroup="FeedbackGroup" OnServerValidate="cvFeedback_ServerValidate"
       ErrorMessage="Feedback must contain at least 10 characters." CssClass="member3-error" />
   </div>
  </div>
  <asp:Button ID="btnSubmit" runat="server" Text="Submit feedback"
      CssClass="member3-primary" ValidationGroup="FeedbackGroup" OnClick="btnSubmit_Click" />
  <h2>My previous feedback</h2>
  <asp:GridView ID="gridHistory" runat="server" AutoGenerateColumns="false"
      CssClass="member3-grid" EmptyDataText="You have not submitted feedback yet.">
   <Columns>
    <asp:BoundField DataField="CreatedDate" HeaderText="Date" DataFormatString="{0:dd MMM yyyy}" />
    <asp:BoundField DataField="Category" HeaderText="Category" />
    <asp:BoundField DataField="Subject" HeaderText="Subject" />
    <asp:BoundField DataField="Rating" HeaderText="Rating" />
    <asp:BoundField DataField="Status" HeaderText="Status" />
    <asp:BoundField DataField="AdminResponse" HeaderText="Admin response" />
   </Columns>
  </asp:GridView>
 </section>
</asp:Content>
