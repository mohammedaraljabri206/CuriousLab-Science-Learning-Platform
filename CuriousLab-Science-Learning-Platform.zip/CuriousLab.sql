﻿USE master;
GO

IF DB_ID(N'CuriousLab') IS NULL
BEGIN
    CREATE DATABASE CuriousLab;
END;
GO

USE CuriousLab;
GO

/* =========================================================
   1. USERS
   ========================================================= */
IF OBJECT_ID(N'dbo.Users', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Users
    (
        UserID INT IDENTITY(1,1) CONSTRAINT PK_Users PRIMARY KEY,
        FullName NVARCHAR(100) NOT NULL,
        Email NVARCHAR(100) NOT NULL CONSTRAINT UQ_Users_Email UNIQUE,
        DateOfBirth DATE NOT NULL,
        MobileNumber NVARCHAR(20) NOT NULL,
        Gender NVARCHAR(20) NOT NULL,
        PasswordHash NVARCHAR(255) NOT NULL,
        Role NVARCHAR(20) NOT NULL
            CONSTRAINT DF_Users_Role DEFAULT N'Student',
        CreatedDate DATETIME NOT NULL
            CONSTRAINT DF_Users_Created DEFAULT GETDATE(),
        IsActive BIT NOT NULL
            CONSTRAINT DF_Users_Active DEFAULT 1,
        CONSTRAINT CK_Users_Role
            CHECK (Role IN (N'Student', N'Admin'))
    );
END;
GO

/* Add Member 4 columns if Users already existed without them. */
IF COL_LENGTH(N'dbo.Users', N'Role') IS NULL
BEGIN
    ALTER TABLE dbo.Users
    ADD Role NVARCHAR(20) NOT NULL
        CONSTRAINT DF_Users_Role_Merged DEFAULT N'Student' WITH VALUES;
END;
GO

IF COL_LENGTH(N'dbo.Users', N'IsActive') IS NULL
BEGIN
    ALTER TABLE dbo.Users
    ADD IsActive BIT NOT NULL
        CONSTRAINT DF_Users_Active_Merged DEFAULT 1 WITH VALUES;
END;
GO

/* =========================================================
   2. EXPERIMENTS — must exist before TheoryTopics
   ========================================================= */
IF OBJECT_ID(N'dbo.Experiments', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Experiments
    (
        ExperimentID INT IDENTITY(1,1) CONSTRAINT PK_Experiments PRIMARY KEY,
        ExperimentName NVARCHAR(150) NOT NULL,
        Difficulty NVARCHAR(20) NOT NULL,
        TimeRequired NVARCHAR(50) NOT NULL,
        Materials NVARCHAR(MAX) NOT NULL,
        ProcedureSteps NVARCHAR(MAX) NOT NULL,
        Safety NVARCHAR(MAX) NOT NULL,
        Explanation NVARCHAR(MAX) NOT NULL,
        ExpectedResult NVARCHAR(MAX) NOT NULL,
        Image NVARCHAR(255) NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_Experiments_Active DEFAULT 1,
        CONSTRAINT CK_Experiments_Difficulty
            CHECK (Difficulty IN (N'Easy', N'Intermediate', N'Advanced'))
    );
END;
GO

/* =========================================================
   3. THEORY TOPICS
   ========================================================= */
IF OBJECT_ID(N'dbo.TheoryTopics', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.TheoryTopics
    (
        TheoryID INT IDENTITY(1,1) CONSTRAINT PK_TheoryTopics PRIMARY KEY,
        Title NVARCHAR(100) NOT NULL,
        ShortDescription NVARCHAR(300) NOT NULL,
        Introduction NVARCHAR(MAX) NOT NULL,
        KeyConcepts NVARCHAR(MAX) NOT NULL,
        RealLifeExamples NVARCHAR(MAX) NOT NULL,
        ImagePath NVARCHAR(255) NOT NULL,
        RelatedExperimentID INT NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_TheoryTopics_Active DEFAULT 1,
        CONSTRAINT FK_Theory_Experiment
            FOREIGN KEY (RelatedExperimentID)
            REFERENCES dbo.Experiments(ExperimentID)
            ON DELETE SET NULL
    );
END;
GO

/* =========================================================
   4. QUIZ QUESTIONS
   ========================================================= */
IF OBJECT_ID(N'dbo.QuizQuestions', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.QuizQuestions
    (
        QuestionID INT IDENTITY(1,1) CONSTRAINT PK_QuizQuestions PRIMARY KEY,
        QuestionText NVARCHAR(1000) NOT NULL,
        OptionA NVARCHAR(300) NOT NULL,
        OptionB NVARCHAR(300) NOT NULL,
        OptionC NVARCHAR(300) NOT NULL,
        OptionD NVARCHAR(300) NOT NULL,
        CorrectOption NCHAR(1) NOT NULL,
        Explanation NVARCHAR(1000) NULL,
        IsActive BIT NOT NULL
            CONSTRAINT DF_QuizQuestions_Active DEFAULT 1,
        CONSTRAINT CK_QuizQuestions_Correct
            CHECK (CorrectOption IN (N'A', N'B', N'C', N'D'))
    );
END;
GO

/* =========================================================
   5. QUIZ ATTEMPTS
   ========================================================= */
IF OBJECT_ID(N'dbo.QuizAttempts', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.QuizAttempts
    (
        AttemptID INT IDENTITY(1,1) CONSTRAINT PK_QuizAttempts PRIMARY KEY,
        UserID INT NOT NULL,
        QuestionID INT NOT NULL,
        SelectedOption NCHAR(1) NOT NULL,
        IsCorrect BIT NOT NULL,
        AttemptDate DATETIME NOT NULL
            CONSTRAINT DF_QuizAttempts_Date DEFAULT GETDATE(),
        CONSTRAINT FK_QuizAttempts_User
            FOREIGN KEY (UserID) REFERENCES dbo.Users(UserID),
        CONSTRAINT FK_QuizAttempts_Question
            FOREIGN KEY (QuestionID) REFERENCES dbo.QuizQuestions(QuestionID)
    );
END;
GO

/* =========================================================
   6. FEEDBACK
   ========================================================= */
IF OBJECT_ID(N'dbo.Feedback', N'U') IS NULL
BEGIN
    CREATE TABLE dbo.Feedback
    (
        FeedbackID INT IDENTITY(1,1) CONSTRAINT PK_Feedback PRIMARY KEY,
        UserID INT NOT NULL,
        Category NVARCHAR(30) NOT NULL
            CONSTRAINT DF_Feedback_Category DEFAULT N'Other',
        Subject NVARCHAR(150) NOT NULL,
        Message NVARCHAR(2000) NOT NULL,
        Rating INT NOT NULL,
        Status NVARCHAR(20) NOT NULL
            CONSTRAINT DF_Feedback_Status DEFAULT N'New',
        AdminResponse NVARCHAR(1000) NULL,
        CreatedDate DATETIME NOT NULL
            CONSTRAINT DF_Feedback_Date DEFAULT GETDATE(),
        CONSTRAINT FK_Feedback_User
            FOREIGN KEY (UserID) REFERENCES dbo.Users(UserID),
        CONSTRAINT CK_Feedback_Rating
            CHECK (Rating BETWEEN 1 AND 5),
        CONSTRAINT CK_Feedback_Status
            CHECK (Status IN (N'New', N'Reviewed', N'Resolved'))
    );
END;
GO

/* Add James's Category column when Feedback already existed. */
IF OBJECT_ID(N'dbo.Feedback', N'U') IS NOT NULL
   AND COL_LENGTH(N'dbo.Feedback', N'Category') IS NULL
BEGIN
    ALTER TABLE dbo.Feedback
    ADD Category NVARCHAR(30) NOT NULL
        CONSTRAINT DF_Feedback_Category_M3
        DEFAULT N'Other' WITH VALUES;
END;
GO

/* =========================================================
   7. DEFAULT ADMIN
   Email: admin@curiouslab.com
   Password: Admin123!
   ========================================================= */
IF NOT EXISTS
(
    SELECT 1
    FROM dbo.Users
    WHERE Email = N'admin@curiouslab.com'
)
BEGIN
    INSERT INTO dbo.Users
    (
        FullName, Email, DateOfBirth, MobileNumber, Gender,
        PasswordHash, Role, CreatedDate, IsActive
    )
    VALUES
    (
        N'CuriousLab Administrator',
        N'admin@curiouslab.com',
        '2000-01-01',
        N'Not supplied',
        N'Not supplied',
        N'100000.oOoA0nmUXlUO/xkM+dQjpQ==.IPXLQexoa5g2B3s8RlFyCDr8dn8RKrxB9VMBHG0QkCk=',
        N'Admin',
        GETDATE(),
        1
    );
END;
GO

/* =========================================================
   8. EXPERIMENT DATA
   ========================================================= */
IF NOT EXISTS (SELECT 1 FROM dbo.Experiments)
BEGIN
    INSERT INTO dbo.Experiments
    (
        ExperimentName, Difficulty, TimeRequired, Materials,
        ProcedureSteps, Safety, Explanation, ExpectedResult, Image
    )
    VALUES
    (N'Baking Soda and Vinegar',N'Easy',N'15 minutes',N'Baking soda|Vinegar|Cup',N'Add vinegar to the cup, then slowly add baking soda.',N'Use eye protection and work on a washable surface.',N'An acid-base reaction releases carbon dioxide gas.',N'Bubbles and foam are produced.',N'acid-base.jpg'),
    (N'Walking Water',N'Easy',N'45 minutes',N'Cups|Water|Food colouring|Paper towels',N'Connect alternating filled cups with folded paper towels.',N'Use food-safe colouring and wipe spills.',N'Capillary action moves coloured water between cups.',N'Water travels and colours mix.',N'walking-water.jpg'),
    (N'Invisible Ink',N'Easy',N'30 minutes',N'Lemon juice|Paper|Cotton bud',N'Write with lemon juice, allow it to dry, then warm under adult supervision.',N'Adult supervision is required when warming paper.',N'Organic compounds oxidise and darken with heat.',N'The hidden writing becomes visible.',N'invisible-ink.jpg'),
    (N'Elephant Toothpaste',N'Intermediate',N'25 minutes',N'Hydrogen peroxide|Yeast|Dish soap|Bottle',N'Combine soap and peroxide, then add activated yeast.',N'Wear gloves and goggles; do not touch the foam.',N'Yeast catalyses decomposition of hydrogen peroxide.',N'A rapid column of foam forms.',N'Elephant-Toothpaste.png'),
    (N'Rainbow Milk',N'Intermediate',N'15 minutes',N'Milk|Food colouring|Dish soap',N'Add colour drops to milk and touch with a soap-covered cotton bud.',N'Do not consume experiment materials.',N'Soap changes surface tension and interacts with fats.',N'Colours rapidly swirl across the milk.',N'rainbow-milk.jpg'),
    (N'Lava Lamp',N'Intermediate',N'20 minutes',N'Oil|Water|Food colouring|Effervescent tablet',N'Layer water and oil, add colour, then add tablet pieces.',N'Do not seal the container during the reaction.',N'Gas bubbles carry coloured water through less dense oil.',N'Coloured bubbles rise and fall.',N'lava-lamp.jpg'),
    (N'Crystal Growing',N'Advanced',N'1-3 days',N'Hot water|Borax or salt|Jar|Pipe cleaner',N'Make a saturated solution and suspend a pipe cleaner.',N'Adult supervision is required for hot water.',N'Dissolved particles form an ordered solid as solution cools.',N'Visible crystals grow over time.',N'crystal-growing.jpg'),
    (N'Electrolysis of Water',N'Advanced',N'40 minutes',N'Low-voltage supply|Electrodes|Water',N'Connect electrodes to a low-voltage source and observe bubbles.',N'Use only a low-voltage educational supply.',N'Electric current separates water into gases.',N'Gas bubbles form at both electrodes.',N'electrolysis.jpg'),
    (N'Copper Plating',N'Advanced',N'45 minutes',N'Copper solution|Copper strip|Metal object|Low-voltage supply',N'Connect and immerse electrodes, then apply low voltage.',N'Wear gloves and follow teacher supervision.',N'Copper ions gain electrons and deposit on the object.',N'A copper-coloured coating forms.',N'copper-plating.jpg');
END;
GO

/* =========================================================
   9. THEORY DATA
   ========================================================= */
IF NOT EXISTS (SELECT 1 FROM dbo.TheoryTopics)
BEGIN
    INSERT INTO dbo.TheoryTopics
    (
        Title, ShortDescription, Introduction, KeyConcepts,
        RealLifeExamples, ImagePath, RelatedExperimentID
    )
    VALUES
    (N'Atoms and Molecules',N'Learn about the tiny particles that make up everything around us.',N'All matter is made of extremely small particles called atoms. Atoms can join together to form molecules. Different combinations of atoms produce different substances.',N'Atoms|Molecules|Elements|Compounds|Chemical bonds',N'Water is made from hydrogen and oxygen atoms.|Oxygen gas contains oxygen molecules.|Table salt contains sodium and chlorine particles.',N'~/Images/atoms-molecules.png',NULL),
    (N'States of Matter',N'Discover the differences between solids, liquids, and gases.',N'Matter commonly exists as a solid, liquid, or gas. These states differ because their particles are arranged and move in different ways.',N'Solid|Liquid|Gas|Melting|Freezing|Evaporation|Condensation',N'Ice is a solid.|Water is a liquid.|Steam and water vapour are gases.',N'~/Images/states-of-matter.jpg',NULL),
    (N'Chemical Reactions',N'Understand how substances change into new substances.',N'A chemical reaction happens when one or more substances change and form new substances. The starting substances are called reactants and the new substances are called products.',N'Reactants|Products|Colour change|Gas production|Temperature change|Precipitate',N'Rust forming on iron.|Baking soda reacting with vinegar.|Wood burning in air.',N'~/Images/chemical-reactions.jpg',1),
    (N'Acids and Bases',N'Explore acids, bases, neutral substances, and the pH scale.',N'Acids and bases are groups of substances with different chemical properties. The pH scale is used to show whether a substance is acidic, neutral, or alkaline.',N'Acid|Base|Alkali|Neutral|pH scale|Neutralisation',N'Lemon juice is acidic.|Pure water is neutral.|Soap is usually alkaline.',N'~/Images/acids-bases.jpg',1),
    (N'Density',N'Learn why some objects float while others sink.',N'Density describes how much matter is packed into a certain amount of space. An object usually floats when it is less dense than the liquid around it.',N'Mass|Volume|Density|Floating|Sinking',N'Cork floats on water.|Many metals sink in water.|Oil floats above water.',N'~/Images/density.jpg',NULL),
    (N'Solutions and Mixtures',N'Learn what happens when substances are mixed or dissolved.',N'A mixture is formed when substances are combined without creating a new substance. A solution is a mixture in which one substance dissolves evenly in another.',N'Mixture|Solution|Solute|Solvent|Dissolving|Filtration',N'Salt dissolves in water.|Sand and water form a mixture.|Air is a mixture of gases.',N'~/Images/solutions-mixtures.jpg',NULL),
    (N'Indicators',N'Discover how indicators help identify acids and bases.',N'Indicators are substances that change colour depending on whether a solution is acidic, neutral, or alkaline. They can be used to estimate pH.',N'Indicator|Litmus paper|Universal indicator|Colour change|pH',N'Blue litmus turns red in acid.|Red litmus turns blue in alkali.|Universal indicator shows several colours.',N'~/Images/indicators.jpg',NULL),
    (N'Energy Changes',N'Understand how reactions absorb or release energy.',N'Chemical reactions may release energy or absorb energy from their surroundings. Reactions that release heat are exothermic, while reactions that absorb heat are endothermic.',N'Exothermic|Endothermic|Heat energy|Temperature change|Activation energy',N'Burning fuel releases heat.|Some instant cold packs absorb heat.|Combustion is exothermic.',N'~/Images/energy-changes.jpg',NULL);
END;
GO

/* =========================================================
   10. QUIZ DATA
   ========================================================= */
IF NOT EXISTS
(
    SELECT 1 FROM dbo.QuizQuestions
    WHERE QuestionText = N'Which gas is released when baking soda reacts with vinegar?'
)
BEGIN
    INSERT INTO dbo.QuizQuestions
    (QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Explanation)
    VALUES
    (N'Which gas is released when baking soda reacts with vinegar?',N'Oxygen',N'Carbon dioxide',N'Nitrogen',N'Hydrogen',N'B',N'The acid-base reaction releases carbon dioxide gas.');
END;
GO

IF NOT EXISTS
(
    SELECT 1 FROM dbo.QuizQuestions
    WHERE QuestionText = N'What is the pH of a neutral solution at room temperature?'
)
BEGIN
    INSERT INTO dbo.QuizQuestions
    (QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Explanation)
    VALUES
    (N'What is the pH of a neutral solution at room temperature?',N'1',N'5',N'7',N'14',N'C',N'A neutral solution has a pH of approximately 7.');
END;
GO

IF NOT EXISTS
(
    SELECT 1 FROM dbo.QuizQuestions
    WHERE QuestionText = N'Which state of matter has a fixed volume but takes the shape of its container?'
)
BEGIN
    INSERT INTO dbo.QuizQuestions
    (QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Explanation)
    VALUES
    (N'Which state of matter has a fixed volume but takes the shape of its container?',N'Solid',N'Liquid',N'Gas',N'Plasma',N'B',N'A liquid keeps its volume but takes the shape of its container.');
END;
GO

IF NOT EXISTS
(
    SELECT 1 FROM dbo.QuizQuestions
    WHERE QuestionText = N'What happens to particles when a substance is heated?'
)
BEGIN
    INSERT INTO dbo.QuizQuestions
    (QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Explanation)
    VALUES
    (N'What happens to particles when a substance is heated?',N'They stop moving',N'They usually move faster',N'They disappear',N'They become atoms',N'B',N'Heating increases particle kinetic energy, so particles usually move faster.');
END;
GO

IF NOT EXISTS
(
    SELECT 1 FROM dbo.QuizQuestions
    WHERE QuestionText = N'Which item is required for safe chemistry practical work?'
)
BEGIN
    INSERT INTO dbo.QuizQuestions
    (QuestionText, OptionA, OptionB, OptionC, OptionD, CorrectOption, Explanation)
    VALUES
    (N'Which item is required for safe chemistry practical work?',N'Safety goggles',N'Open-toed shoes',N'Food',N'Loose clothing',N'A',N'Safety goggles protect the eyes from splashes and particles.');
END;
GO

/* =========================================================
   11. FINAL VERIFICATION
   ========================================================= */
SELECT
    DB_NAME() AS CurrentDatabase,
    OBJECT_ID(N'dbo.Users', N'U') AS UsersTable,
    OBJECT_ID(N'dbo.Experiments', N'U') AS ExperimentsTable,
    OBJECT_ID(N'dbo.TheoryTopics', N'U') AS TheoryTopicsTable,
    OBJECT_ID(N'dbo.QuizQuestions', N'U') AS QuizQuestionsTable,
    OBJECT_ID(N'dbo.QuizAttempts', N'U') AS QuizAttemptsTable,
    OBJECT_ID(N'dbo.Feedback', N'U') AS FeedbackTable;
GO

SELECT N'CuriousLab database setup completed successfully.' AS Result;
GO
